import { useState } from 'react';
import { Calculator, Sparkles } from 'lucide-react';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { Field, Input } from '@/components/Field';
import { BarChart } from '@/components/Charts';
import { PageHeader } from '@/components/Layout';
import { calculateProfitCalculator, formatCurrency, formatPercent, formatNumber } from '@/lib/financial';

export function CalculatorPage() {
  const [revenue, setRevenue] = useState(0);
  const [fixedCosts, setFixedCosts] = useState(0);
  const [variableCosts, setVariableCosts] = useState(0);
  const [productPrice, setProductPrice] = useState(0);
  const [result, setResult] = useState<ReturnType<typeof calculateProfitCalculator> | null>(null);

  const handleCalculate = () => {
    setResult(calculateProfitCalculator(revenue, fixedCosts, variableCosts, productPrice));
  };

  return (
    <div>
      <PageHeader title="حاسبة الأرباح والتكاليف" subtitle="احسب الأرباح ونقطة التعادل وهامش المساهمة" icon={<Calculator size={24} />} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <Card className="p-6">
          <h3 className="text-lg font-bold text-white mb-4">البيانات</h3>
          <Field label="الإيرادات">
            <Input type="number" value={revenue || ''} onChange={(e) => setRevenue(parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="التكاليف الثابتة">
            <Input type="number" value={fixedCosts || ''} onChange={(e) => setFixedCosts(parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="التكاليف المتغيرة">
            <Input type="number" value={variableCosts || ''} onChange={(e) => setVariableCosts(parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="سعر المنتج / الوحدة">
            <Input type="number" value={productPrice || ''} onChange={(e) => setProductPrice(parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Button onClick={handleCalculate} icon={<Sparkles size={20} />} fullWidth size="lg">
            احسب
          </Button>
        </Card>

        {result && (
          <Card className="p-6 animate-slide-up" glow="green">
            <h3 className="text-lg font-bold text-white mb-4">النتائج</h3>
            <div className="space-y-3">
              <ResultRow label="إجمالي التكاليف" value={formatCurrency(result.totalCosts)} />
              <ResultRow label="صافي الربح" value={formatCurrency(result.netProfit)} highlight={result.netProfit > 0 ? 'green' : 'red'} />
              <ResultRow label="هامش الربح" value={formatPercent(result.profitMargin)} highlight={result.profitMargin > 0 ? 'blue' : 'red'} />
              <ResultRow label="نقطة التعادل (وحدات)" value={`${formatNumber(result.breakEvenUnits)} وحدة`} />
              <ResultRow label="إيراد نقطة التعادل" value={formatCurrency(result.breakEvenRevenue)} />
              <ResultRow label="هامش المساهمة" value={formatCurrency(result.contributionMargin)} />
            </div>
            <div className="mt-4">
              <BarChart
                data={[
                  { label: 'الإيرادات', value: revenue, color: '#00e676' },
                  { label: 'التكاليف', value: result.totalCosts, color: '#ff5252' },
                  { label: 'صافي الربح', value: result.netProfit, color: '#00b0ff' },
                ]}
                formatValue={(v) => formatCurrency(v)}
              />
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}

function ResultRow({ label, value, highlight }: { label: string; value: string; highlight?: 'green' | 'red' | 'blue' }) {
  const color = highlight === 'green' ? 'text-neon-green' : highlight === 'red' ? 'text-red-400' : highlight === 'blue' ? 'text-neon-blue' : 'text-white';
  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-xl bg-navy-950/40">
      <span className="text-sm text-gray-400">{label}</span>
      <span className={`text-sm font-bold ${color}`}>{value}</span>
    </div>
  );
}
