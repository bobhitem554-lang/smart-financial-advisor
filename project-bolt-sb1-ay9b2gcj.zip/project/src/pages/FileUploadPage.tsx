import { useState, useRef, useEffect } from 'react';
import { Upload, FileText, AlertCircle, CheckCircle, X, Sparkles, FileSpreadsheet, FileImage, FileType } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useRouter } from '@/lib/router';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { Badge } from '@/components/Badge';
import { Spinner } from '@/components/Spinner';
import { PageHeader } from '@/components/Layout';
import { parseFile, isAcceptedFile, type ParsedFileData } from '@/lib/fileParser';
import { supabase } from '@/lib/supabase';
import { trackUsage, getUsageCount } from '@/lib/usage';
import { formatNumber } from '@/lib/financial';

export function FileUploadPage() {
  const { navigate } = useRouter();
  const { user, profile, planLimits } = useAuth();
  const [files, setFiles] = useState<{ name: string; data: ParsedFileData | null; status: 'uploading' | 'done' | 'error' }[]>([]);
  const [dragOver, setDragOver] = useState(false);
  const [usageCount, setUsageCount] = useState(0);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (user) getUsageCount(user.id, 'file_upload').then(setUsageCount);
  }, [user]);

  const limit = planLimits?.max_file_uploads ?? 3;

  const handleFiles = async (fileList: FileList) => {
    const newFiles = Array.from(fileList);
    for (const file of newFiles) {
      if (!isAcceptedFile(file)) {
        setFiles((prev) => [...prev, { name: file.name, data: null, status: 'error' }]);
        continue;
      }

      setFiles((prev) => [...prev, { name: file.name, data: null, status: 'uploading' }]);

      const parsed = await parseFile(file);

      setFiles((prev) => prev.map((f) =>
        f.name === file.name && f.status === 'uploading'
          ? { name: file.name, data: parsed, status: parsed.success ? 'done' : 'error' }
          : f
      ));

      if (user && parsed.success) {
        await supabase.from('file_uploads').insert({
          user_id: user.id,
          file_name: file.name,
          file_type: file.type || file.name.split('.').pop() || '',
          file_size: file.size,
          extracted_data: { summary: parsed.summary, numbers: parsed.numbers, tables: parsed.tables },
          status: 'completed',
        });
        await trackUsage(user.id, 'file_upload');
        setUsageCount((c) => c + 1);
      }
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setDragOver(false);
    if (e.dataTransfer.files.length > 0) handleFiles(e.dataTransfer.files);
  };

  const removeFile = (name: string) => {
    setFiles((prev) => prev.filter((f) => f.name !== name));
  };

  const getFileIcon = (name: string) => {
    const ext = name.split('.').pop()?.toLowerCase();
    if (ext === 'pdf') return <FileType size={20} className="text-red-400" />;
    if (ext === 'xlsx' || ext === 'xls' || ext === 'csv') return <FileSpreadsheet size={20} className="text-neon-green" />;
    if (ext === 'png' || ext === 'jpg' || ext === 'jpeg') return <FileImage size={20} className="text-neon-blue" />;
    return <FileText size={20} className="text-gray-400" />;
  };

  return (
    <div>
      <PageHeader title="رفع ملف مالي" subtitle="ارفع تقريراً مالياً لاستخراج الأرقام وتحليلها" icon={<Upload size={24} />} />

      {profile && planLimits && (
        <Card className="p-4 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <Sparkles size={16} className="text-neon-green" />
            <span>الاستخدام: {usageCount} / {limit} ملف</span>
          </div>
          <Badge variant={usageCount >= limit ? 'warning' : 'success'} size="sm">
            {usageCount >= limit ? 'وصلت للحد' : 'متاح'}
          </Badge>
        </Card>
      )}

      <Card
        className={`p-8 mb-6 border-2 border-dashed transition-all ${dragOver ? 'border-neon-green/50 bg-neon-green/5' : 'border-navy-700/50'}`}
      >
        <div
          onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
          onDragLeave={() => setDragOver(false)}
          onDrop={handleDrop}
          className="flex flex-col items-center text-center cursor-pointer"
          onClick={() => fileInputRef.current?.click()}
        >
          <div className="w-16 h-16 rounded-2xl bg-neon-green/10 flex items-center justify-center mb-4">
            <Upload size={28} className="text-neon-green" />
          </div>
          <h3 className="text-lg font-bold text-white mb-2">اسحب الملفات هنا أو انقر للاختيار</h3>
          <p className="text-sm text-gray-400 mb-2">الأنواع المدعومة: PDF, Excel, Word, CSV, صور</p>
          <p className="text-xs text-gray-500">تُحذف جميع الملفات والبيانات تلقائياً بعد 24 ساعة</p>
          <input
            ref={fileInputRef}
            type="file"
            multiple
            accept=".pdf,.xlsx,.xls,.docx,.doc,.csv,.txt,.png,.jpg,.jpeg,.webp"
            className="hidden"
            onChange={(e) => e.target.files && handleFiles(e.target.files)}
          />
        </div>
      </Card>

      {/* File list */}
      {files.length > 0 && (
        <div className="space-y-4">
          {files.map((f, i) => (
            <Card key={i} className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  {getFileIcon(f.name)}
                  <div>
                    <p className="text-sm font-medium text-white">{f.name}</p>
                    {f.status === 'uploading' && <p className="text-xs text-gray-500">جاري المعالجة...</p>}
                    {f.status === 'done' && <Badge variant="success" size="sm"><CheckCircle size={12} /> تم</Badge>}
                    {f.status === 'error' && <Badge variant="error" size="sm"><AlertCircle size={12} /> فشل</Badge>}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {f.data?.success && (
                    <Button size="sm" variant="ghost" icon={<Sparkles size={14} />} onClick={() => navigate('advisor', { context: 'file' })}>
                      اسأل المستشار
                    </Button>
                  )}
                  <button onClick={() => removeFile(f.name)} className="text-gray-400 hover:text-red-400 p-1">
                    <X size={18} />
                  </button>
                </div>
              </div>

              {f.status === 'uploading' && (
                <div className="flex items-center gap-3 py-3">
                  <Spinner size="sm" />
                  <span className="text-sm text-gray-400">جاري قراءة وتحليل الملف...</span>
                </div>
              )}

              {f.status === 'error' && f.data?.error && (
                <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-400">
                  {f.data.error}
                </div>
              )}

              {f.status === 'done' && f.data && (
                <div className="space-y-3">
                  <p className="text-sm text-gray-300">{f.data.summary}</p>

                  {f.data.numbers.length > 0 && (
                    <div>
                      <h4 className="text-xs font-bold text-gray-400 mb-2">الأرقام المستخرجة ({f.data.numbers.length})</h4>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {f.data.numbers.slice(0, 10).map((n, j) => (
                          <div key={j} className="flex items-center justify-between px-3 py-2 rounded-lg bg-navy-950/40 text-xs">
                            <span className="text-gray-400 truncate ml-2">{n.label}</span>
                            <span className="text-neon-green font-bold whitespace-nowrap">{formatNumber(n.value)}</span>
                          </div>
                        ))}
                      </div>
                      {f.data.numbers.length > 10 && (
                        <p className="text-xs text-gray-500 mt-2">+ {f.data.numbers.length - 10} قيمة أخرى</p>
                      )}
                    </div>
                  )}

                  {f.data.tables.length > 0 && (
                    <div>
                      <h4 className="text-xs font-bold text-gray-400 mb-2">الجدول المستخرج</h4>
                      <div className="overflow-x-auto">
                        <table className="w-full text-xs">
                          <thead>
                            <tr className="border-b border-navy-700">
                              {f.data.tables[0].headers.map((h, j) => (
                                <th key={j} className="text-right p-2 text-gray-400">{h}</th>
                              ))}
                            </tr>
                          </thead>
                          <tbody>
                            {f.data.tables[0].rows.slice(0, 5).map((row, j) => (
                              <tr key={j} className="border-b border-navy-800/50">
                                {row.map((cell, k) => (
                                  <td key={k} className="p-2 text-gray-300">{cell}</td>
                                ))}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </Card>
          ))}
        </div>
      )}

      <Card className="p-5 mt-6 border-amber-500/20">
        <div className="flex items-start gap-3">
          <AlertCircle size={20} className="text-amber-400 shrink-0 mt-0.5" />
          <div>
            <h4 className="text-sm font-bold text-white mb-1">ملاحظة حول قراءة الملفات</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              يقوم النظام باستخراج النصوص والأرقام المتاحة من ملفاتك. إذا فشل الاستخراج (مثلاً ملف PDF ممسوح ضوئياً)، سيظهر لك تنبيه واضح. لا ندّعي قراءة ملف إذا تعذّر استخراج بياناته. للحصول على أفضل النتائج، استخدم ملفات CSV أو PDF تحتوي على نص قابل للقراءة.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
