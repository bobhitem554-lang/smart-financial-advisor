import {
  FileSearch, BarChart3, Upload, MessageCircle, Calculator,
  TrendingUp, ArrowLeft, Crown, Shield, Clock, Zap,
} from 'lucide-react';
import { useRouter } from '@/lib/router';
import { useAuth } from '@/lib/auth';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { Badge } from '@/components/Badge';
import { RobotMascot } from '@/components/RobotMascot';

export function HomePage() {
  const { navigate } = useRouter();
  const { profile } = useAuth();

  const features = [
    { route: 'feasibility' as const, label: 'دراسة جدوى جديدة', desc: 'تحليل شامل لمشروعك مع التوصيات', icon: <FileSearch size={24} />, color: 'green' },
    { route: 'financial' as const, label: 'تحليل مشروع', desc: 'تحليل الإيرادات والمصروفات والأرباح', icon: <BarChart3 size={24} />, color: 'blue' },
    { route: 'files' as const, label: 'تحليل تقرير مالي', desc: 'ارفع تقريراً واستخرج الأرقام', icon: <Upload size={24} />, color: 'green' },
    { route: 'calculator' as const, label: 'حاسبة الأرباح والتكاليف', desc: 'احسب الأرباح ونقطة التعادل', icon: <Calculator size={24} />, color: 'blue' },
    { route: 'scenarios' as const, label: 'السيناريوهات', desc: 'متفائل، واقعي، متشائم', icon: <TrendingUp size={24} />, color: 'green' },
    { route: 'advisor' as const, label: 'اسأل المستشار الذكي', desc: 'محادثة مع المستشار المالي', icon: <MessageCircle size={24} />, color: 'blue' },
  ];

  const colorMap: Record<string, string> = {
    green: 'text-neon-green border-neon-green/20 bg-neon-green/5',
    blue: 'text-neon-blue border-neon-blue/20 bg-neon-blue/5',
  };

  return (
    <div className="space-y-8">
      {/* Hero */}
      <div className="text-center pt-8 pb-4 animate-fade-in">
        <div className="flex justify-center mb-6">
          <RobotMascot size="xl" />
        </div>
        <h1 className="text-3xl sm:text-4xl font-bold text-white mb-3 text-balance">
          مستشارك المالي الذكي
        </h1>
        <p className="text-lg text-gray-400 max-w-xl mx-auto text-balance">
          حلّل مشروعك، افهم أرقامك، واتخذ قرارك بثقة.
        </p>
      </div>

      {/* Plan card */}
      <Card className="p-5 flex items-center justify-between" hover>
        <div className="flex items-center gap-3">
          {profile?.plan === 'premium' ? (
            <>
              <div className="w-12 h-12 rounded-xl gradient-blue flex items-center justify-center">
                <Crown size={24} className="text-white" />
              </div>
              <div>
                <p className="text-sm text-gray-400">خطتك الحالية</p>
                <p className="text-lg font-bold text-neon-blue">Premium</p>
              </div>
            </>
          ) : (
            <>
              <div className="w-12 h-12 rounded-xl bg-gray-700/40 flex items-center justify-center">
                <Shield size={24} className="text-gray-300" />
              </div>
              <div>
                <p className="text-sm text-gray-400">خطتك الحالية</p>
                <p className="text-lg font-bold text-gray-200">مجاني</p>
              </div>
            </>
          )}
        </div>
        <div className="flex items-center gap-2">
          {profile ? (
            <Badge variant={profile.plan === 'premium' ? 'premium' : 'free'} size="md">
              {profile.plan === 'premium' ? <><Crown size={12} /> Premium</> : 'مجاني'}
            </Badge>
          ) : (
            <Button size="sm" variant="secondary" onClick={() => navigate('signup')} icon={<Zap size={16} />}>
              ابدأ مجاناً
            </Button>
          )}
        </div>
      </Card>

      {/* Feature grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {features.map((f, i) => (
          <Card
            key={f.route}
            className="p-6 group"
            hover
            onClick={() => navigate(f.route)}
          >
            <div className={`w-14 h-14 rounded-2xl border flex items-center justify-center mb-4 transition-all group-hover:scale-110 ${colorMap[f.color]}`}>
              {f.icon}
            </div>
            <h3 className="text-lg font-bold text-white mb-1">{f.label}</h3>
            <p className="text-sm text-gray-400">{f.desc}</p>
            <div className="flex items-center gap-1 mt-3 text-neon-green text-sm opacity-0 group-hover:opacity-100 transition-opacity">
              <span>ابدأ الآن</span>
              <ArrowLeft size={16} />
            </div>
          </Card>
        ))}
      </div>

      {/* Privacy notice */}
      <Card className="p-5 border-neon-green/10">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-neon-green/10 flex items-center justify-center shrink-0">
            <Clock size={20} className="text-neon-green" />
          </div>
          <div>
            <h4 className="text-sm font-bold text-white mb-1">خصوصيتك محمية</h4>
            <p className="text-xs text-gray-400 leading-relaxed">
              جميع البيانات والملفات المؤقتة ترتبط بوقت الإنشاء وتُحذف تلقائياً بعد 24 ساعة كحد أقصى. لا نحتفظ بملفاتك أو تقاريرك المالية بعد انتهاء هذه المدة.
            </p>
          </div>
        </div>
      </Card>
    </div>
  );
}
