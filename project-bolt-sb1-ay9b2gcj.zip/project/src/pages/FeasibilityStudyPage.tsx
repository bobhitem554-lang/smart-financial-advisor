import { useState, useEffect } from 'react';
import { FileSearch, Sparkles, Download, Save, AlertCircle, CheckCircle } from 'lucide-react';
import { useRouter } from '@/lib/router';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { Field, Input, Select, Textarea } from '@/components/Field';
import { Badge } from '@/components/Badge';
import { Spinner } from '@/components/Spinner';
import { BarChart, LineChart } from '@/components/Charts';
import { PageHeader, UpgradePrompt } from '@/components/Layout';
import { calculateFeasibility, formatCurrency, formatPercent, formatNumber } from '@/lib/financial';
import { trackUsage, getUsageCount } from '@/lib/usage';
import { supabase } from '@/lib/supabase';
import type { FeasibilityInput, FeasibilityResults } from '@/lib/types';
import { generateReport } from '@/lib/report';

const projectTypes = [
  'مطعم', 'مقهى', 'متجر تجزئة', 'متجر إلكتروني', 'خدمات استشارية',
  'تقنية معلومات', 'صناعة', 'زراعة', 'عقارات', 'نقل وخدمات لوجستية',
  'صحة وطب', 'تعليم', 'سياحة', 'تجميل وعناية', 'أخرى',
];

const countries = ['السعودية', 'الإمارات', 'مصر', 'الأردن', 'الكويت', 'قطر', 'البحرين', 'عمان', 'المغرب', 'العراق', 'السودان', 'اليمن', 'تونس', 'الجزائر', 'ليبيا', 'أخرى'];

const currencies = ['ريال', 'درهم', 'جنيه', 'دينار', 'دولار', 'يورو', 'درهم مغربي', 'جنيه سوداني', 'أخرى'];

const emptyInput: FeasibilityInput = {
  project_name: '', project_type: '', country: '', city: '', currency: 'ريال',
  capital: 0, setup_costs: 0, monthly_expenses: 0, product_cost: 0,
  employee_count: 0, salaries: 0, rent: 0, marketing: 0,
  expected_monthly_revenue: 0, expected_customers: 0, product_price: 0,
  additional_info: '',
};

export function FeasibilityStudyPage() {
  const { navigate } = useRouter();
  const { user, profile, planLimits } = useAuth();
  const [input, setInput] = useState<FeasibilityInput>(emptyInput);
  const [results, setResults] = useState<FeasibilityResults | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [usageCount, setUsageCount] = useState<number>(0);

  useEffect(() => {
    if (user) {
      getUsageCount(user.id, 'feasibility_study').then(setUsageCount);
    }
  }, [user]);

  const update = (field: keyof FeasibilityInput, value: string | number) => {
    setInput((prev) => ({ ...prev, [field]: value }));
  };

  const handleAnalyze = () => {
    if (!input.project_name.trim()) {
      setError('الرجاء إدخال اسم المشروع');
      return;
    }

    setError(null);
    setLoading(true);

    setTimeout(() => {
      const res = calculateFeasibility(input);
      setResults(res);
      setLoading(false);
      window.scrollTo({ top: 300, behavior: 'smooth' });
    }, 800);
  };

  const handleSave = async () => {
    if (!user || !results) return;
    setSaving(true);
    setError(null);

    const limit = planLimits?.max_feasibility_studies ?? 3;
    if (usageCount >= limit) {
      setError('لقد وصلت إلى الحد الأقصى من دراسات الجدوى في خطتك الحالية. يمكنك الترقية إلى Premium.');
      setSaving(false);
      return;
    }

    const { error: err } = await supabase.from('feasibility_studies').insert({
      user_id: user.id,
      ...input,
      results: results as unknown as Record<string, never>,
    });

    if (err) {
      setError('حدث خطأ أثناء الحفظ. حاول مرة أخرى.');
      setSaving(false);
      return;
    }

    await trackUsage(user.id, 'feasibility_study');
    setUsageCount((c) => c + 1);
    setSaved(true);
    setSaving(false);
  };

  const handleDownloadReport = () => {
    if (!results) return;
    generateReport({
      type: 'feasibility',
      projectName: input.project_name,
      projectType: input.project_type,
      country: input.country,
      city: input.city,
      currency: input.currency,
      input,
      results,
    });
  };

  const limit = planLimits?.max_feasibility_studies ?? 3;
  const reachedLimit = usageCount >= limit;

  return (
    <div>
      <PageHeader
        title="دراسة جدوى جديدة"
        subtitle="أدخل بيانات مشروعك للحصول على تحليل شامل"
        icon={<FileSearch size={24} />}
      />

      {profile && planLimits && (
        <Card className="p-4 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <Sparkles size={16} className="text-neon-green" />
            <span>الاستخدام: {usageCount} / {limit} دراسة جدوى</span>
          </div>
          <Badge variant={reachedLimit ? 'warning' : 'success'} size="sm">
            {reachedLimit ? 'وصلت للحد' : 'متاح'}
          </Badge>
        </Card>
      )}

      {/* Form */}
      <Card className="p-6 mb-6">
        <h3 className="text-lg font-bold text-white mb-4">بيانات المشروع</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
          <Field label="اسم المشروع" required>
            <Input value={input.project_name} onChange={(e) => update('project_name', e.target.value)} placeholder="مثال: مقهى الذواقة" />
          </Field>
          <Field label="نوع المشروع">
            <Select value={input.project_type} onChange={(e) => update('project_type', e.target.value)}>
              <option value="">اختر النوع</option>
              {projectTypes.map((t) => <option key={t} value={t}>{t}</option>)}
            </Select>
          </Field>
          <Field label="الدولة">
            <Select value={input.country} onChange={(e) => update('country', e.target.value)}>
              <option value="">اختر الدولة</option>
              {countries.map((c) => <option key={c} value={c}>{c}</option>)}
            </Select>
          </Field>
          <Field label="المدينة">
            <Input value={input.city} onChange={(e) => update('city', e.target.value)} placeholder="مثال: الرياض" />
          </Field>
          <Field label="العملة">
            <Select value={input.currency} onChange={(e) => update('currency', e.target.value)}>
              {currencies.map((c) => <option key={c} value={c}>{c}</option>)}
            </Select>
          </Field>
          <Field label="رأس المال" hint="إجمالي رأس المال المتاح">
            <Input type="number" value={input.capital || ''} onChange={(e) => update('capital', parseFloat(e.target.value) || 0)} suffix={input.currency} />
          </Field>
        </div>

        <h3 className="text-lg font-bold text-white mb-4 mt-6 pt-4 border-t border-navy-700/40">التكاليف</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
          <Field label="تكاليف التأسيس" hint="تكاليف一次性 قبل الإطلاق">
            <Input type="number" value={input.setup_costs || ''} onChange={(e) => update('setup_costs', parseFloat(e.target.value) || 0)} suffix={input.currency} />
          </Field>
          <Field label="المصاريف الشهرية" hint="مصاريف تشغيلية أخرى">
            <Input type="number" value={input.monthly_expenses || ''} onChange={(e) => update('monthly_expenses', parseFloat(e.target.value) || 0)} suffix={input.currency} />
          </Field>
          <Field label="تكلفة المنتجات / الخدمات" hint="تكلفة البضاعة المباعة">
            <Input type="number" value={input.product_cost || ''} onChange={(e) => update('product_cost', parseFloat(e.target.value) || 0)} suffix={input.currency} />
          </Field>
          <Field label="الإيجار الشهري">
            <Input type="number" value={input.rent || ''} onChange={(e) => update('rent', parseFloat(e.target.value) || 0)} suffix={input.currency} />
          </Field>
          <Field label="عدد الموظفين">
            <Input type="number" value={input.employee_count || ''} onChange={(e) => update('employee_count', parseInt(e.target.value) || 0)} suffix="موظف" />
          </Field>
          <Field label="إجمالي الرواتب الشهرية">
            <Input type="number" value={input.salaries || ''} onChange={(e) => update('salaries', parseFloat(e.target.value) || 0)} suffix={input.currency} />
          </Field>
          <Field label="ميزانية التسويق الشهرية">
            <Input type="number" value={input.marketing || ''} onChange={(e) => update('marketing', parseFloat(e.target.value) || 0)} suffix={input.currency} />
          </Field>
        </div>

        <h3 className="text-lg font-bold text-white mb-4 mt-6 pt-4 border-t border-navy-700/40">الإيرادات المتوقعة</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
          <Field label="الإيرادات الشهرية المتوقعة" hint="اتركها 0 ليتم حسابها تلقائياً">
            <Input type="number" value={input.expected_monthly_revenue || ''} onChange={(e) => update('expected_monthly_revenue', parseFloat(e.target.value) || 0)} suffix={input.currency} />
          </Field>
          <Field label="عدد العملاء المتوقع شهرياً">
            <Input type="number" value={input.expected_customers || ''} onChange={(e) => update('expected_customers', parseInt(e.target.value) || 0)} suffix="عميل" />
          </Field>
          <Field label="سعر المنتج / الخدمة">
            <Input type="number" value={input.product_price || ''} onChange={(e) => update('product_price', parseFloat(e.target.value) || 0)} suffix={input.currency} />
          </Field>
        </div>

        <Field label="معلومات إضافية عن المشروع" hint="أي تفاصيل تساعد في التحليل">
          <Textarea rows={3} value={input.additional_info} onChange={(e) => update('additional_info', e.target.value)} placeholder="مثال: المشروع يستهدف فئة الشباب في منطقة تجارية مزدحمة..." />
        </Field>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-400 flex items-center gap-2">
            <AlertCircle size={18} />
            {error}
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3">
          <Button onClick={handleAnalyze} loading={loading} size="lg" icon={<Sparkles size={20} />} fullWidth>
            {loading ? 'جاري التحليل...' : 'تحليل المشروع'}
          </Button>
          {results && user && (
            <Button onClick={handleSave} loading={saving} variant="outline" size="lg" icon={<Save size={20} />} fullWidth>
              {saved ? 'تم الحفظ' : 'حفظ الدراسة'}
            </Button>
          )}
        </div>
      </Card>

      {/* Loading */}
      {loading && (
        <Card className="p-8 mb-6 flex flex-col items-center gap-4">
          <Spinner size="lg" />
          <p className="text-gray-400 text-sm">جاري تحليل بيانات مشروعك...</p>
        </Card>
      )}

      {/* Results */}
      {results && !loading && (
        <div className="space-y-4 animate-slide-up">
          {/* Summary */}
          <Card className="p-6" glow="green">
            <div className="flex items-center gap-2 mb-3">
              <CheckCircle size={20} className="text-neon-green" />
              <h3 className="text-lg font-bold text-white">ملخص المشروع</h3>
            </div>
            <p className="text-gray-300 leading-relaxed text-sm">{results.summary}</p>
          </Card>

          {/* Key metrics */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Card className="p-4">
              <p className="text-xs text-gray-400 mb-1">صافي الربح الشهري</p>
              <p className={`text-xl font-bold ${results.netProfit > 0 ? 'text-neon-green' : 'text-red-400'}`}>
                {formatCurrency(results.netProfit, input.currency)}
              </p>
            </Card>
            <Card className="p-4">
              <p className="text-xs text-gray-400 mb-1">هامش الربح</p>
              <p className={`text-xl font-bold ${results.profitMargin > 0 ? 'text-neon-blue' : 'text-red-400'}`}>
                {formatPercent(results.profitMargin)}
              </p>
            </Card>
            <Card className="p-4">
              <p className="text-xs text-gray-400 mb-1">نقطة التعادل</p>
              <p className="text-xl font-bold text-amber-400">{formatNumber(results.breakEvenPoint)} وحدة</p>
            </Card>
            <Card className="p-4">
              <p className="text-xs text-gray-400 mb-1">فترة الاسترداد</p>
              <p className="text-xl font-bold text-neon-blue">
                {results.paybackPeriod > 0 ? `${formatNumber(results.paybackPeriod)} سنة` : '—'}
              </p>
            </Card>
          </div>

          {/* Revenue vs Costs chart */}
          <Card className="p-6">
            <h4 className="text-sm font-bold text-white mb-4">الإيرادات مقابل التكاليف</h4>
            <BarChart
              data={[
                { label: 'الإيرادات', value: results.monthlyRevenue, color: '#00e676' },
                { label: 'التكاليف', value: results.totalMonthlyCosts, color: '#ff5252' },
                { label: 'صافي الربح', value: results.netProfit, color: '#00b0ff' },
              ]}
              formatValue={(v) => formatCurrency(v, input.currency)}
            />
          </Card>

          {/* 12-month forecast */}
          <Card className="p-6">
            <h4 className="text-sm font-bold text-white mb-4">توقعات 12 شهراً</h4>
            <LineChart
              data={results.forecasts.map((f) => ({ label: `ش${f.month}`, value: f.revenue, value2: f.expenses }))}
              showSecond
              color="#00e676"
              color2="#ff5252"
              height={220}
            />
            <div className="flex items-center gap-4 mt-3 text-xs">
              <div className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-neon-green" /> الإيرادات</div>
              <div className="flex items-center gap-1.5"><span className="w-3 h-0.5 bg-red-400" /> المصروفات</div>
            </div>
          </Card>

          {/* Market Analysis */}
          <Card className="p-6">
            <h4 className="text-sm font-bold text-white mb-2">تحليل السوق المبدئي</h4>
            <p className="text-gray-300 text-sm leading-relaxed">{results.marketAnalysis}</p>
          </Card>

          {/* SWOT */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="p-5">
              <h4 className="text-sm font-bold text-neon-green mb-3">نقاط القوة</h4>
              <ul className="space-y-2">
                {results.strengths.map((s, i) => (
                  <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                    <CheckCircle size={16} className="text-neon-green shrink-0 mt-0.5" />
                    {s}
                  </li>
                ))}
              </ul>
            </Card>
            <Card className="p-5">
              <h4 className="text-sm font-bold text-red-400 mb-3">نقاط الضعف</h4>
              <ul className="space-y-2">
                {results.weaknesses.map((w, i) => (
                  <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                    <AlertCircle size={16} className="text-red-400 shrink-0 mt-0.5" />
                    {w}
                  </li>
                ))}
              </ul>
            </Card>
            <Card className="p-5">
              <h4 className="text-sm font-bold text-amber-400 mb-3">المخاطر</h4>
              <ul className="space-y-2">
                {results.risks.map((r, i) => (
                  <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                    <AlertCircle size={16} className="text-amber-400 shrink-0 mt-0.5" />
                    {r}
                  </li>
                ))}
              </ul>
            </Card>
            <Card className="p-5">
              <h4 className="text-sm font-bold text-neon-blue mb-3">الفرص</h4>
              <ul className="space-y-2">
                {results.opportunities.map((o, i) => (
                  <li key={i} className="text-sm text-gray-300 flex items-start gap-2">
                    <Sparkles size={16} className="text-neon-blue shrink-0 mt-0.5" />
                    {o}
                  </li>
                ))}
              </ul>
            </Card>
          </div>

          {/* Recommendations */}
          <Card className="p-6" glow="blue">
            <h4 className="text-sm font-bold text-white mb-3">توصيات المستشار</h4>
            <ol className="space-y-2">
              {results.recommendations.map((r, i) => (
                <li key={i} className="text-sm text-gray-300 flex items-start gap-3">
                  <span className="w-6 h-6 rounded-lg bg-neon-blue/20 text-neon-blue text-xs font-bold flex items-center justify-center shrink-0">
                    {i + 1}
                  </span>
                  {r}
                </li>
              ))}
            </ol>
          </Card>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 pb-6">
            <Button onClick={handleDownloadReport} variant="secondary" size="lg" icon={<Download size={20} />} fullWidth>
              تنزيل تقرير PDF
            </Button>
            <Button onClick={() => navigate('advisor', { context: 'feasibility' })} variant="outline" size="lg" icon={<Sparkles size={20} />} fullWidth>
              اسأل المستشار عن النتائج
            </Button>
          </div>
        </div>
      )}

      {reachedLimit && profile?.plan === 'free' && !results && (
        <div className="mt-4">
          <UpgradePrompt
            message={`لقد وصلت إلى الحد الأقصى (${limit} دراسات جدوى) في الخطة المجانية. ترقَّ إلى Premium لتحليلات غير محدودة.`}
            onUpgrade={() => navigate('profile')}
          />
        </div>
      )}
    </div>
  );
}
