import { useState } from 'react';
import { TrendingUp, Smile, Target, Frown, Sparkles, Download } from 'lucide-react';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { Field, Input } from '@/components/Field';
import { Badge } from '@/components/Badge';
import { ComparisonBar } from '@/components/Charts';
import { PageHeader } from '@/components/Layout';
import { calculateScenarios, formatCurrency, formatNumber } from '@/lib/financial';
import type { ScenarioData } from '@/lib/types';

const scenarioIcons: Record<string, typeof Smile> = {
  optimistic: Smile,
  realistic: Target,
  pessimistic: Frown,
};

export function ScenariosPage() {
  const [revenue, setRevenue] = useState(0);
  const [expenses, setExpenses] = useState(0);
  const [investment, setInvestment] = useState(0);
  const [scenarios, setScenarios] = useState<ScenarioData[] | null>(null);

  const handleAnalyze = () => {
    setScenarios(calculateScenarios(revenue, expenses, investment, 'ريال'));
  };

  const maxValue = scenarios ? Math.max(...scenarios.map((s) => Math.max(s.revenue, s.expenses, Math.abs(s.profit)))) : 1;

  return (
    <div>
      <PageHeader title="تحليل السيناريوهات" subtitle="قارن بين السيناريو المتفائل والواقعي والمتشائم" icon={<TrendingUp size={24} />} />

      <Card className="p-6 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-x-4">
          <Field label="الإيرادات الشهرية">
            <Input type="number" value={revenue || ''} onChange={(e) => setRevenue(parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="المصروفات الشهرية">
            <Input type="number" value={expenses || ''} onChange={(e) => setExpenses(parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="الاستثمار الأولي">
            <Input type="number" value={investment || ''} onChange={(e) => setInvestment(parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
        </div>
        <Button onClick={handleAnalyze} icon={<Sparkles size={20} />} size="lg" fullWidth>
          تحليل السيناريوهات
        </Button>
      </Card>

      {scenarios && (
        <div className="space-y-4 animate-slide-up">
          {/* Scenario cards */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
            {scenarios.map((s) => {
              const Icon = scenarioIcons[s.name];
              return (
                <Card key={s.name} className="p-5" >
                  <div className="flex items-center gap-2 mb-3">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center" style={{ backgroundColor: `${s.color}15` }}>
                      <Icon size={20} style={{ color: s.color }} />
                    </div>
                    <h4 className="font-bold text-white" style={{ color: s.color }}>{s.label}</h4>
                  </div>
                  <div className="space-y-2 text-sm">
                    <Row label="الإيرادات" value={formatCurrency(s.revenue)} />
                    <Row label="المصروفات" value={formatCurrency(s.expenses)} />
                    <Row label="الربح" value={formatCurrency(s.profit)} color={s.profit > 0 ? 'text-neon-green' : 'text-red-400'} />
                    <Row label="التدفق النقدي" value={formatCurrency(s.cashFlow)} color={s.cashFlow > 0 ? 'text-neon-green' : 'text-red-400'} />
                    <Row label="فترة الاسترداد" value={s.paybackPeriod > 0 ? `${formatNumber(s.paybackPeriod)} سنة` : '—'} />
                  </div>
                </Card>
              );
            })}
          </div>

          {/* Comparison charts */}
          <Card className="p-6">
            <h4 className="text-sm font-bold text-white mb-4">مقارنة الإيرادات</h4>
            <ComparisonBar
              label="الإيرادات"
              values={scenarios.map((s) => ({ label: s.label, value: s.revenue, color: s.color }))}
              max={maxValue}
              formatValue={(v) => formatCurrency(v)}
            />
            <ComparisonBar
              label="المصروفات"
              values={scenarios.map((s) => ({ label: s.label, value: s.expenses, color: s.color }))}
              max={maxValue}
              formatValue={(v) => formatCurrency(v)}
            />
            <ComparisonBar
              label="صافي الربح"
              values={scenarios.map((s) => ({ label: s.label, value: s.profit, color: s.color }))}
              max={maxValue}
              formatValue={(v) => formatCurrency(v)}
            />
          </Card>

          {/* Summary table */}
          <Card className="p-6">
            <h4 className="text-sm font-bold text-white mb-3">الجدول المقارن</h4>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-navy-700">
                    <th className="text-right p-2 text-gray-400">المؤشر</th>
                    {scenarios.map((s) => (
                      <th key={s.name} className="text-right p-2" style={{ color: s.color }}>{s.label}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr className="border-b border-navy-800/50">
                    <td className="p-2 text-gray-400">الإيرادات</td>
                    {scenarios.map((s) => <td key={s.name} className="p-2 text-gray-200">{formatCurrency(s.revenue)}</td>)}
                  </tr>
                  <tr className="border-b border-navy-800/50">
                    <td className="p-2 text-gray-400">المصروفات</td>
                    {scenarios.map((s) => <td key={s.name} className="p-2 text-gray-200">{formatCurrency(s.expenses)}</td>)}
                  </tr>
                  <tr className="border-b border-navy-800/50">
                    <td className="p-2 text-gray-400">الربح</td>
                    {scenarios.map((s) => <td key={s.name} className={`p-2 font-bold ${s.profit > 0 ? 'text-neon-green' : 'text-red-400'}`}>{formatCurrency(s.profit)}</td>)}
                  </tr>
                  <tr className="border-b border-navy-800/50">
                    <td className="p-2 text-gray-400">التدفق النقدي</td>
                    {scenarios.map((s) => <td key={s.name} className={`p-2 ${s.cashFlow > 0 ? 'text-neon-green' : 'text-red-400'}`}>{formatCurrency(s.cashFlow)}</td>)}
                  </tr>
                  <tr>
                    <td className="p-2 text-gray-400">فترة الاسترداد</td>
                    {scenarios.map((s) => <td key={s.name} className="p-2 text-gray-200">{s.paybackPeriod > 0 ? `${formatNumber(s.paybackPeriod)} سنة` : '—'}</td>)}
                  </tr>
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      )}
    </div>
  );
}

function Row({ label, value, color }: { label: string; value: string; color?: string }) {
  return (
    <div className="flex items-center justify-between">
      <span className="text-gray-400">{label}</span>
      <span className={`font-bold ${color || 'text-white'}`}>{value}</span>
    </div>
  );
}
