import { useState, useEffect } from 'react';
import { Shield, Users, BarChart3, FileSearch, Upload, Settings, Activity, Crown } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { Card } from '@/components/Card';
import { Badge } from '@/components/Badge';
import { PageHeader } from '@/components/Layout';
import { supabase } from '@/lib/supabase';
import { formatNumber } from '@/lib/financial';

interface AdminStats {
  totalUsers: number;
  freeUsers: number;
  premiumUsers: number;
  totalStudies: number;
  totalAnalyses: number;
  totalUploads: number;
}

export function AdminPage() {
  const { profile } = useAuth();
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [recentUsers, setRecentUsers] = useState<{ id: string; email: string; plan: string; created_at: string }[]>([]);

  useEffect(() => {
    (async () => {
      const { count: users } = await supabase.from('profiles').select('*', { count: 'exact', head: true });
      const { count: free } = await supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('plan', 'free');
      const { count: premium } = await supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('plan', 'premium');
      const { count: studies } = await supabase.from('feasibility_studies').select('*', { count: 'exact', head: true });
      const { count: analyses } = await supabase.from('financial_analyses').select('*', { count: 'exact', head: true });
      const { count: uploads } = await supabase.from('file_uploads').select('*', { count: 'exact', head: true });
      setStats({
        totalUsers: users ?? 0,
        freeUsers: free ?? 0,
        premiumUsers: premium ?? 0,
        totalStudies: studies ?? 0,
        totalAnalyses: analyses ?? 0,
        totalUploads: uploads ?? 0,
      });

      const { data: ru } = await supabase
        .from('profiles')
        .select('id, email, plan, created_at')
        .order('created_at', { ascending: false })
        .limit(10);
      if (ru) setRecentUsers(ru as typeof recentUsers);
    })();
  }, []);

  if (profile?.role !== 'admin') {
    return (
      <Card className="p-6 text-center">
        <Shield size={32} className="text-amber-400 mx-auto mb-3" />
        <p className="text-gray-300">هذه الصفحة مخصصة للمشرفين فقط.</p>
      </Card>
    );
  }

  const statCards = [
    { label: 'إجمالي المستخدمين', value: stats ? formatNumber(stats.totalUsers) : '—', icon: <Users size={20} />, color: 'text-neon-blue' },
    { label: 'مستخدمي Premium', value: stats ? formatNumber(stats.premiumUsers) : '—', icon: <Crown size={20} />, color: 'text-neon-blue' },
    { label: 'مستخدمي المجاني', value: stats ? formatNumber(stats.freeUsers) : '—', icon: <Users size={20} />, color: 'text-gray-300' },
    { label: 'دراسات الجدوى', value: stats ? formatNumber(stats.totalStudies) : '—', icon: <FileSearch size={20} />, color: 'text-neon-green' },
    { label: 'التحليلات المالية', value: stats ? formatNumber(stats.totalAnalyses) : '—', icon: <BarChart3 size={20} />, color: 'text-neon-green' },
    { label: 'الملفات المرفوعة', value: stats ? formatNumber(stats.totalUploads) : '—', icon: <Upload size={20} />, color: 'text-neon-green' },
  ];

  return (
    <div>
      <PageHeader title="لوحة الإدارة" subtitle="نظرة عامة على النظام والمستخدمين" icon={<Shield size={24} />} />

      {/* Stats grid */}
      <div className="grid grid-cols-2 lg:grid-cols-3 gap-3 mb-6">
        {statCards.map((s, i) => (
          <Card key={i} className="p-5">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-xs text-gray-400 mb-1">{s.label}</p>
                <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
              </div>
              <div className={`text-2xl ${s.color}`}>{s.icon}</div>
            </div>
          </Card>
        ))}
      </div>

      {/* Recent users */}
      <Card className="p-6 mb-4">
        <div className="flex items-center gap-2 mb-4">
          <Activity size={18} className="text-neon-green" />
          <h3 className="text-sm font-bold text-white">أحدث المستخدمين</h3>
        </div>
        {recentUsers.length === 0 ? (
          <p className="text-sm text-gray-500">لا يوجد مستخدمون بعد.</p>
        ) : (
          <div className="space-y-2">
            {recentUsers.map((u) => (
              <div key={u.id} className="flex items-center justify-between py-2 px-3 rounded-xl bg-navy-950/40">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-full bg-navy-700 flex items-center justify-center text-xs font-bold text-white">
                    {u.email[0].toUpperCase()}
                  </div>
                  <span className="text-sm text-gray-300">{u.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={u.plan === 'premium' ? 'premium' : 'free'} size="sm">
                    {u.plan === 'premium' ? 'Premium' : 'مجاني'}
                  </Badge>
                  <span className="text-xs text-gray-500">{new Date(u.created_at).toLocaleDateString('ar-EG')}</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </Card>

      {/* Settings placeholder */}
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-3">
          <Settings size={18} className="text-neon-blue" />
          <h3 className="text-sm font-bold text-white">إعدادات النظام</h3>
        </div>
        <p className="text-sm text-gray-400">يمكن إدارة حدود الخطط وإعدادات التطبيق من هنا لاحقاً. المحتوى المالي للمستخدمين لا يُعرض في لوحة الإدارة حفاظاً على الخصوصية.</p>
      </Card>
    </div>
  );
}
