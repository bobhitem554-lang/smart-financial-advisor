import { useState, useEffect } from 'react';
import { BarChart3, Sparkles, Download, Save, AlertCircle } from 'lucide-react';
import { useRouter } from '@/lib/router';
import { useAuth } from '@/lib/auth';
import { Button } from '@/components/Button';
import { Card } from '@/components/Card';
import { Field, Input } from '@/components/Field';
import { Badge } from '@/components/Badge';
import { Spinner } from '@/components/Spinner';
import { BarChart, DonutChart } from '@/components/Charts';
import { PageHeader } from '@/components/Layout';
import { calculateFinancial, formatCurrency, formatPercent, formatNumber } from '@/lib/financial';
import { trackUsage, getUsageCount } from '@/lib/usage';
import { supabase } from '@/lib/supabase';
import type { FinancialInput, FinancialResults } from '@/lib/types';
import { generateReport } from '@/lib/report';

const emptyInput: FinancialInput = {
  title: 'تحليل مالي',
  revenue: 0, expenses: 0, fixed_expenses: 0, variable_expenses: 0,
  assets: 0, liabilities: 0, cash_inflow: 0, cash_outflow: 0,
};

export function FinancialAnalysisPage() {
  const { navigate } = useRouter();
  const { user, profile, planLimits } = useAuth();
  const [input, setInput] = useState<FinancialInput>(emptyInput);
  const [results, setResults] = useState<FinancialResults | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [usageCount, setUsageCount] = useState(0);

  useEffect(() => {
    if (user) getUsageCount(user.id, 'financial_analysis').then(setUsageCount);
  }, [user]);

  const update = (field: keyof FinancialInput, value: string | number) => {
    setInput((prev) => ({ ...prev, [field]: value }));
  };

  const handleAnalyze = () => {
    setError(null);
    setLoading(true);
    setTimeout(() => {
      const res = calculateFinancial(input);
      setResults(res);
      setLoading(false);
    }, 600);
  };

  const handleSave = async () => {
    if (!user || !results) return;
    setSaving(true);
    const limit = planLimits?.max_financial_analyses ?? 5;
    if (usageCount >= limit) {
      setError('لقد وصلت إلى الحد الأقصى من التحليلات المالية في خطتك.');
      setSaving(false);
      return;
    }
    const { error: err } = await supabase.from('financial_analyses').insert({
      user_id: user.id,
      ...input,
      results: results as unknown as Record<string, never>,
    });
    if (err) { setError('حدث خطأ أثناء الحفظ.'); setSaving(false); return; }
    await trackUsage(user.id, 'financial_analysis');
    setUsageCount((c) => c + 1);
    setSaved(true);
    setSaving(false);
  };

  const handleDownload = () => {
    if (!results) return;
    generateReport({ type: 'financial', projectName: input.title, currency: 'ريال', input, results });
  };

  const limit = planLimits?.max_financial_analyses ?? 5;

  return (
    <div>
      <PageHeader title="تحليل مالي" subtitle="حلّل الإيرادات والمصروفات والأرباح والمؤشرات المالية" icon={<BarChart3 size={24} />} />

      {profile && planLimits && (
        <Card className="p-4 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-gray-400">
            <Sparkles size={16} className="text-neon-green" />
            <span>الاستخدام: {usageCount} / {limit} تحليل</span>
          </div>
          <Badge variant={usageCount >= limit ? 'warning' : 'success'} size="sm">
            {usageCount >= limit ? 'وصلت للحد' : 'متاح'}
          </Badge>
        </Card>
      )}

      <Card className="p-6 mb-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4">
          <Field label="عنوان التحليل">
            <Input value={input.title} onChange={(e) => update('title', e.target.value)} placeholder="مثال: تحليل الربع الأول" />
          </Field>
          <Field label="الإيرادات">
            <Input type="number" value={input.revenue || ''} onChange={(e) => update('revenue', parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="إجمالي المصروفات">
            <Input type="number" value={input.expenses || ''} onChange={(e) => update('expenses', parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="المصروفات الثابتة">
            <Input type="number" value={input.fixed_expenses || ''} onChange={(e) => update('fixed_expenses', parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="المصروفات المتغيرة">
            <Input type="number" value={input.variable_expenses || ''} onChange={(e) => update('variable_expenses', parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="الأصول">
            <Input type="number" value={input.assets || ''} onChange={(e) => update('assets', parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="الخصوم">
            <Input type="number" value={input.liabilities || ''} onChange={(e) => update('liabilities', parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="التدفق النقدي الداخل">
            <Input type="number" value={input.cash_inflow || ''} onChange={(e) => update('cash_inflow', parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
          <Field label="التدفق النقدي الخارج">
            <Input type="number" value={input.cash_outflow || ''} onChange={(e) => update('cash_outflow', parseFloat(e.target.value) || 0)} suffix="ريال" />
          </Field>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-400 flex items-center gap-2">
            <AlertCircle size={18} /> {error}
          </div>
        )}

        <div className="flex flex-col sm:flex-row gap-3">
          <Button onClick={handleAnalyze} loading={loading} size="lg" icon={<Sparkles size={20} />} fullWidth>
            {loading ? 'جاري التحليل...' : 'تحليل مالي'}
          </Button>
          {results && user && (
            <Button onClick={handleSave} loading={saving} variant="outline" size="lg" icon={<Save size={20} />} fullWidth>
              {saved ? 'تم الحفظ' : 'حفظ التحليل'}
            </Button>
          )}
        </div>
      </Card>

      {loading && (
        <Card className="p-8 flex flex-col items-center gap-4">
          <Spinner size="lg" />
          <p className="text-gray-400 text-sm">جاري التحليل المالي...</p>
        </Card>
      )}

      {results && !loading && (
        <div className="space-y-4 animate-slide-up">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            <Card className="p-4">
              <p className="text-xs text-gray-400 mb-1">صافي الربح</p>
              <p className={`text-xl font-bold ${results.netProfit > 0 ? 'text-neon-green' : 'text-red-400'}`}>{formatCurrency(results.netProfit)}</p>
            </Card>
            <Card className="p-4">
              <p className="text-xs text-gray-400 mb-1">هامش الربح</p>
              <p className={`text-xl font-bold ${results.profitMargin > 0 ? 'text-neon-blue' : 'text-red-400'}`}>{formatPercent(results.profitMargin)}</p>
            </Card>
            <Card className="p-4">
              <p className="text-xs text-gray-400 mb-1">صافي التدفق النقدي</p>
              <p className={`text-xl font-bold ${results.netCashFlow > 0 ? 'text-neon-green' : 'text-red-400'}`}>{formatCurrency(results.netCashFlow)}</p>
            </Card>
            <Card className="p-4">
              <p className="text-xs text-gray-400 mb-1">العائد على الأصول</p>
              <p className="text-xl font-bold text-amber-400">{formatPercent(results.roa)}</p>
            </Card>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
            <Card className="p-6">
              <h4 className="text-sm font-bold text-white mb-4">الإيرادات مقابل المصروفات</h4>
              <BarChart data={results.charts.revenueVsExpenses} formatValue={(v) => formatCurrency(v)} />
            </Card>
            <Card className="p-6">
              <h4 className="text-sm font-bold text-white mb-4">هيكل التكاليف</h4>
              <DonutChart data={results.charts.costBreakdown} centerValue={formatPercent(results.fixedCostRatio)} centerLabel="نسبة الثابتة" />
            </Card>
            <Card className="p-6">
              <h4 className="text-sm font-bold text-white mb-4">التدفقات النقدية</h4>
              <BarChart data={results.charts.cashFlow} formatValue={(v) => formatCurrency(v)} />
            </Card>
            <Card className="p-6">
              <h4 className="text-sm font-bold text-white mb-4">الأصول والخصوم</h4>
              <BarChart data={results.charts.assetsLiabilities} formatValue={(v) => formatCurrency(v)} />
            </Card>
          </div>

          <Card className="p-6">
            <h4 className="text-sm font-bold text-white mb-4">مؤشرات الأداء المالي</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <MetricRow label="نقطة التعادل (الإيرادات)" value={formatCurrency(results.breakEvenRevenue)} />
              <MetricRow label="نقطة التعادل (الوحدات)" value={`${formatNumber(results.breakEvenUnits)} وحدة`} />
              <MetricRow label="هامش المساهمة" value={formatCurrency(results.contributionMargin)} />
              <MetricRow label="نسبة هامش المساهمة" value={formatPercent(results.contributionMarginRatio)} />
              <MetricRow label="نسبة الدين إلى الأصول" value={formatPercent(results.debtToAssets)} />
              <MetricRow label="النسبة الجارية" value={formatNumber(results.currentRatio)} />
              <MetricRow label="نسبة المصروفات الثابتة" value={formatPercent(results.fixedCostRatio)} />
              <MetricRow label="نسبة المصروفات المتغيرة" value={formatPercent(results.variableCostRatio)} />
              {results.monthlyBurnRate > 0 && <MetricRow label="معدل الحرق الشهري" value={formatCurrency(results.monthlyBurnRate)} />}
              {results.runway > 0 && <MetricRow label="مدة البقاء (Runway)" value={`${formatNumber(results.runway)} شهر`} />}
            </div>
          </Card>

          <div className="flex flex-col sm:flex-row gap-3 pb-6">
            <Button onClick={handleDownload} variant="secondary" size="lg" icon={<Download size={20} />} fullWidth>
              تنزيل تقرير PDF
            </Button>
            <Button onClick={() => navigate('advisor', { context: 'financial' })} variant="outline" size="lg" icon={<Sparkles size={20} />} fullWidth>
              اسأل المستشار
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function MetricRow({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between py-2 px-3 rounded-xl bg-navy-950/40">
      <span className="text-sm text-gray-400">{label}</span>
      <span className="text-sm font-bold text-white">{value}</span>
    </div>
  );
}
