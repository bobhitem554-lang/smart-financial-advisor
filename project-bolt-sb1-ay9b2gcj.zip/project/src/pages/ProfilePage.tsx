import { useState, useEffect } from 'react';
import { User, Crown, Mail, Calendar, Activity, Shield, Clock, Zap } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useRouter } from '@/lib/router';
import { Card } from '@/components/Card';
import { Badge } from '@/components/Badge';
import { Button } from '@/components/Button';
import { PageHeader } from '@/components/Layout';
import { supabase } from '@/lib/supabase';
import { getUsageCount, timeRemaining } from '@/lib/usage';

export function ProfilePage() {
  const { user, profile, planLimits } = useAuth();
  const { navigate } = useRouter();
  const [usage, setUsage] = useState({ feasibility: 0, financial: 0, files: 0, advisor: 0 });

  useEffect(() => {
    if (!user) return;
    Promise.all([
      getUsageCount(user.id, 'feasibility_study'),
      getUsageCount(user.id, 'financial_analysis'),
      getUsageCount(user.id, 'file_upload'),
      getUsageCount(user.id, 'advisor_message'),
    ]).then(([f, fa, fi, a]) => setUsage({ feasibility: f, financial: fa, files: fi, advisor: a }));
  }, [user]);

  // Fetch recent saved studies for expiry display
  const [recentItems, setRecentItems] = useState<{ id: string; name: string; expires_at: string; type: string }[]>([]);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: studies } = await supabase
        .from('feasibility_studies')
        .select('id, project_name, expires_at')
        .eq('user_id', user.id)
        .order('created_at', { ascending: false })
        .limit(5);
      if (studies) {
        setRecentItems(studies.map((s) => ({ id: s.id, name: s.project_name, expires_at: s.expires_at, type: 'دراسة جدوى' })));
      }
    })();
  }, [user]);

  if (!profile || !planLimits) {
    return <Card className="p-6"><p className="text-gray-400">جاري التحميل...</p></Card>;
  }

  const usageItems = [
    { label: 'دراسات الجدوى', current: usage.feasibility, max: planLimits.max_feasibility_studies },
    { label: 'التحليلات المالية', current: usage.financial, max: planLimits.max_financial_analyses },
    { label: 'رفع الملفات', current: usage.files, max: planLimits.max_file_uploads },
    { label: 'رسائل المستشار', current: usage.advisor, max: planLimits.max_advisor_messages },
  ];

  return (
    <div>
      <PageHeader title="الملف الشخصي" subtitle="إدارة حسابك وخطتك واستخدامك" icon={<User size={24} />} />

      {/* Profile info */}
      <Card className="p-6 mb-4">
        <div className="flex items-center gap-4">
          <div className="w-16 h-16 rounded-2xl gradient-green flex items-center justify-center text-navy-950 text-2xl font-bold">
            {profile.full_name?.[0] || profile.email[0].toUpperCase()}
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-bold text-white">{profile.full_name || 'مستخدم'}</h3>
            <p className="text-sm text-gray-400 flex items-center gap-1"><Mail size={14} /> {profile.email}</p>
            <p className="text-xs text-gray-500 flex items-center gap-1 mt-1"><Calendar size={12} /> عضو منذ {new Date(profile.created_at).toLocaleDateString('ar-EG')}</p>
          </div>
          <Badge variant={profile.plan === 'premium' ? 'premium' : 'free'} size="md">
            {profile.plan === 'premium' ? <><Crown size={12} /> Premium</> : 'مجاني'}
          </Badge>
        </div>
      </Card>

      {/* Plan & limits */}
      <Card className="p-6 mb-4">
        <div className="flex items-center gap-2 mb-4">
          <Shield size={18} className="text-neon-green" />
          <h3 className="text-sm font-bold text-white">الخطة الحالية والحدود</h3>
        </div>
        <div className="space-y-3">
          {usageItems.map((u) => (
            <div key={u.label}>
              <div className="flex items-center justify-between text-sm mb-1">
                <span className="text-gray-400">{u.label}</span>
                <span className="text-gray-300">{u.current} / {u.max}</span>
              </div>
              <div className="h-2 bg-navy-950/60 rounded-full overflow-hidden">
                <div
                  className={`h-full rounded-full transition-all ${u.current >= u.max ? 'bg-red-400' : 'gradient-green'}`}
                  style={{ width: `${Math.min((u.current / u.max) * 100, 100)}%` }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Premium features */}
        <div className="mt-4 pt-4 border-t border-navy-700/40">
          <div className="flex items-center gap-2 mb-3">
            <Crown size={16} className="text-neon-blue" />
            <h4 className="text-sm font-bold text-white">مزايا Premium</h4>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs text-gray-400">
            <Feature available={planLimits.advanced_analysis} label="تحليلات متقدمة" />
            <Feature available={planLimits.advanced_pdf} label="تقارير PDF احترافية" />
            <Feature available={planLimits.scenarios_enabled} label="سيناريوهات متعددة" />
            <Feature available={planLimits.file_analysis_enabled} label="تحليل ملفات" />
            <Feature available={planLimits.max_advisor_messages > 50} label="استخدام أكبر للمستشار" />
            <Feature available={planLimits.max_feasibility_studies > 10} label="دراسات جدوى غير محدودة" />
          </div>
          {profile.plan === 'free' && (
            <Button variant="secondary" size="md" icon={<Zap size={16} />} className="mt-4" fullWidth onClick={() => navigate('plans')}>
              الترقية إلى Premium
            </Button>
          )}
        </div>
      </Card>

      {/* Recent items with expiry */}
      {recentItems.length > 0 && (
        <Card className="p-6">
          <div className="flex items-center gap-2 mb-3">
            <Clock size={18} className="text-amber-400" />
            <h3 className="text-sm font-bold text-white">العناصر الأخيرة (تُحذف تلقائياً بعد 24 ساعة)</h3>
          </div>
          <div className="space-y-2">
            {recentItems.map((item) => (
              <div key={item.id} className="flex items-center justify-between py-2 px-3 rounded-xl bg-navy-950/40">
                <div className="flex items-center gap-2">
                  <Activity size={14} className="text-neon-green" />
                  <span className="text-sm text-gray-300">{item.name}</span>
                </div>
                <span className="text-xs text-amber-400/70">{timeRemaining(item.expires_at)}</span>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

function Feature({ available, label }: { available: boolean; label: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className={`w-4 h-4 rounded-full flex items-center justify-center text-[10px] ${available ? 'bg-neon-green/20 text-neon-green' : 'bg-gray-700/40 text-gray-500'}`}>
        {available ? '✓' : '—'}
      </span>
      <span className={available ? 'text-gray-300' : 'text-gray-500'}>{label}</span>
    </div>
  );
}
