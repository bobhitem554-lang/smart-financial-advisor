import { useState, useRef, useEffect } from 'react';
import { MessageCircle, Send, Sparkles } from 'lucide-react';
import { useRouter } from '@/lib/router';
import { useAuth } from '@/lib/auth';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { RobotMascot } from '@/components/RobotMascot';
import { PageHeader } from '@/components/Layout';
import { generateAdvisorResponse, getQuickQuestions } from '@/lib/advisor';
import type { AdvisorMessage } from '@/lib/types';

export function AdvisorPage() {
  const { params } = useRouter();
  const { user } = useAuth();
  const [messages, setMessages] = useState<AdvisorMessage[]>([
    {
      role: 'advisor',
      content: 'مرحباً بك! أنا مستشارك المالي الذكي. كيف يمكنني مساعدتك اليوم؟',
      timestamp: new Date().toISOString(),
    },
  ]);
  const [input, setInput] = useState('');
  const [thinking, setThinking] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);

  const contextType = (params.context as 'general' | 'feasibility' | 'financial' | 'file') || 'general';
  const quickQuestions = getQuickQuestions(contextType);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, thinking]);

  const handleSend = (text?: string) => {
    const question = text || input.trim();
    if (!question) return;
    setInput('');
    const userMsg: AdvisorMessage = { role: 'user', content: question, timestamp: new Date().toISOString() };
    setMessages((prev) => [...prev, userMsg]);
    setThinking(true);

    setTimeout(() => {
      const response = generateAdvisorResponse(question, { type: contextType });
      setMessages((prev) => [...prev, { role: 'advisor', content: response, timestamp: new Date().toISOString() }]);
      setThinking(false);
    }, 600);
  };

  return (
    <div>
      <PageHeader title="المستشار الذكي" subtitle="اسأل أي سؤال مالي واحصل على إجابة فورية" icon={<MessageCircle size={24} />} />

      <Card className="p-0 overflow-hidden flex flex-col" >
        {/* Messages */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4 min-h-[400px] max-h-[60vh]">
          {messages.map((msg, i) => (
            <div key={i} className={`flex gap-3 ${msg.role === 'user' ? 'flex-row-reverse' : ''}`}>
              {msg.role === 'advisor' && <RobotMascot size="sm" animated={false} />}
              <div
                className={`max-w-[75%] rounded-2xl p-3 text-sm leading-relaxed ${
                  msg.role === 'user'
                    ? 'bg-neon-blue/15 text-gray-100 rounded-tr-sm'
                    : 'bg-navy-800/60 text-gray-200 rounded-tl-sm'
                }`}
              >
                <p className="whitespace-pre-line">{msg.content}</p>
              </div>
            </div>
          ))}
          {thinking && (
            <div className="flex gap-3">
              <RobotMascot size="sm" animated={false} />
              <div className="bg-navy-800/60 rounded-2xl rounded-tl-sm p-3 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-neon-green animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-neon-green animate-bounce" style={{ animationDelay: '0.2s' }} />
                <span className="w-2 h-2 rounded-full bg-neon-green animate-bounce" style={{ animationDelay: '0.4s' }} />
              </div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        {/* Quick questions */}
        {messages.length <= 1 && (
          <div className="px-4 pb-3 flex flex-wrap gap-2">
            {quickQuestions.map((q, i) => (
              <button
                key={i}
                onClick={() => handleSend(q)}
                className="text-xs px-3 py-1.5 rounded-full bg-navy-800/60 text-gray-300 hover:bg-neon-green/10 hover:text-neon-green transition-all border border-navy-700/50"
              >
                {q}
              </button>
            ))}
          </div>
        )}

        {/* Input */}
        <div className="border-t border-navy-700/40 p-3 flex gap-2">
          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            placeholder="اكتب سؤالك هنا..."
            className="flex-1 bg-navy-950/50 border border-navy-700/60 rounded-xl px-4 py-2.5 text-gray-100 placeholder-gray-500 focus:outline-none focus:border-neon-green/40 text-sm"
          />
          <Button onClick={() => handleSend()} size="sm" icon={<Send size={18} />}>
            إرسال
          </Button>
        </div>
      </Card>

      {!user && (
        <p className="text-center text-xs text-gray-500 mt-4">
          <Sparkles size={12} className="inline ml-1" />
          أنشئ حساباً لحفظ محادثاتك والوصول إلى مزيد من الميزات
        </p>
      )}
    </div>
  );
}
