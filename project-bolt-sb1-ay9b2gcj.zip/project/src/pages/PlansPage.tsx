import { Check, Crown, Zap, Shield } from 'lucide-react';
import { useRouter } from '@/lib/router';
import { useAuth } from '@/lib/auth';
import { Card } from '@/components/Card';
import { Button } from '@/components/Button';
import { Badge } from '@/components/Badge';
import { PageHeader } from '@/components/Layout';

export function PlansPage() {
  const { navigate } = useRouter();
  const { profile } = useAuth();

  const freeFeatures = [
    '3 دراسات جدوى شهرياً',
    '5 تحليلات مالية شهرياً',
    '3 ملفات مرفوعة شهرياً',
    '10 رسائل للمستشار الذكي',
    'دراسة جدوى أساسية',
    'حسابات مالية أساسية',
    'تقارير PDF أساسية',
  ];

  const premiumFeatures = [
    'دراسات جدوى غير محدودة',
    'تحليلات مالية متقدمة',
    'رفع وتحليل الملفات',
    'سيناريوهات متعددة',
    '500 رسالة للمستشار الذكي',
    'تقارير PDF احترافية',
    'تحليلات مالية متقدمة',
    'دعم أولوية',
  ];

  return (
    <div>
      <PageHeader title="خطط الاشتراك" subtitle="اختر الخطة المناسبة لاحتياجاتك" icon={<Crown size={24} />} />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Free Plan */}
        <Card className={`p-8 ${profile?.plan === 'free' ? 'border-neon-green/30' : ''}`}>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl bg-gray-700/40 flex items-center justify-center">
              <Shield size={24} className="text-gray-300" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">الخطة المجانية</h3>
              <p className="text-sm text-gray-400">ابدأ مجاناً</p>
            </div>
          </div>
          <p className="text-3xl font-bold text-white mb-1">
            0 <span className="text-base font-normal text-gray-400">{profile?.plan === 'free' ? 'خطتك الحالية' : 'مجاناً'}</span>
          </p>
          {profile?.plan === 'free' && (
            <Badge variant="free" size="sm" >
              <Check size={12} /> خطتك الحالية
            </Badge>
          )}
          <ul className="space-y-3 mt-6">
            {freeFeatures.map((f, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
                <Check size={16} className="text-neon-green shrink-0 mt-0.5" />
                {f}
              </li>
            ))}
          </ul>
          {profile?.plan !== 'free' && (
            <Button variant="outline" fullWidth className="mt-6" onClick={() => navigate('signup')}>
              ابدأ مجاناً
            </Button>
          )}
        </Card>

        {/* Premium Plan */}
        <Card className={`p-8 border-neon-blue/30 ${profile?.plan !== 'premium' ? 'glow-blue' : ''}`}>
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 rounded-xl gradient-blue flex items-center justify-center">
              <Crown size={24} className="text-white" />
            </div>
            <div>
              <h3 className="text-xl font-bold text-white">الخطة Premium</h3>
              <p className="text-sm text-gray-400">احترافية</p>
            </div>
          </div>
          <p className="text-3xl font-bold text-neon-blue mb-1">
            Premium
          </p>
          {profile?.plan === 'premium' && (
            <Badge variant="premium" size="sm">
              <Check size={12} /> خطتك الحالية
            </Badge>
          )}
          <ul className="space-y-3 mt-6">
            {premiumFeatures.map((f, i) => (
              <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
                <Check size={16} className="text-neon-blue shrink-0 mt-0.5" />
                {f}
              </li>
            ))}
          </ul>
          {profile?.plan !== 'premium' && (
            <div className="mt-6 space-y-3">
              <div className="p-4 rounded-xl bg-amber-500/10 border border-amber-500/20 text-sm text-amber-300">
                الدفع عبر Stripe سيكون متاحاً قريباً. النظام جاهز لربط الدفع عند تفعيله.
              </div>
              {profile ? (
                <Button variant="secondary" fullWidth icon={<Zap size={18} />} disabled>
                  الترقية — قريباً
                </Button>
              ) : (
                <Button variant="secondary" fullWidth icon={<Zap size={18} />} onClick={() => navigate('signup')}>
                  أنشئ حساباً أولاً
                </Button>
              )}
            </div>
          )}
        </Card>
      </div>

      <Card className="p-5 mt-6">
        <p className="text-xs text-gray-400 leading-relaxed text-center">
          حدود الخطط قابلة للتعديل من لوحة الإدارة. جميع البيانات والملفات تُحذف تلقائياً بعد 24 ساعة حفاظاً على خصوصيتك.
        </p>
      </Card>
    </div>
  );
}
