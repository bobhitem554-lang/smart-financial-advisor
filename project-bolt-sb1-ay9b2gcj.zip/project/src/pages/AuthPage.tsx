import { useState } from 'react';
import { Mail, Lock, User as UserIcon, ArrowRight } from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useRouter } from '@/lib/router';
import { Button } from '@/components/Button';
import { Field, Input } from '@/components/Field';
import { RobotMascot } from '@/components/RobotMascot';
import { Card } from '@/components/Card';

interface AuthPageProps {
  mode: 'login' | 'signup';
}

export function AuthPage({ mode }: AuthPageProps) {
  const { signIn, signUp } = useAuth();
  const { navigate } = useRouter();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);

    if (mode === 'signup') {
      const { error: err } = await signUp(email, password, fullName);
      if (err) {
        setError(err);
        setLoading(false);
      } else {
        navigate('home');
      }
    } else {
      const { error: err } = await signIn(email, password);
      if (err) {
        setError(err);
        setLoading(false);
      } else {
        navigate('home');
      }
    }
  };

  const isSignup = mode === 'signup';

  return (
    <div className="min-h-screen gradient-hero grid-pattern flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <RobotMascot size="lg" />
          </div>
          <h1 className="text-2xl font-bold text-white">مستشارك المالي الذكي</h1>
          <p className="text-sm text-gray-400 mt-1">{isSignup ? 'أنشئ حسابك المجاني' : 'أهلاً بعودتك'}</p>
        </div>

        <Card className="p-6">
          <form onSubmit={handleSubmit}>
            {isSignup && (
              <Field label="الاسم الكامل" required>
                <div className="relative">
                  <Input
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="أدخل اسمك الكامل"
                    required
                    className="pr-10"
                  />
                  <UserIcon size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
                </div>
              </Field>
            )}

            <Field label="البريد الإلكتروني" required>
              <div className="relative">
                <Input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="example@email.com"
                  required
                  className="pr-10"
                />
                <Mail size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
              </div>
            </Field>

            <Field label="كلمة المرور" required hint={isSignup ? '6 أحرف على الأقل' : undefined}>
              <div className="relative">
                <Input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  required
                  minLength={6}
                  className="pr-10"
                />
                <Lock size={18} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-500" />
              </div>
            </Field>

            {error && (
              <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/20 text-sm text-red-400">
                {error}
              </div>
            )}

            <Button type="submit" fullWidth loading={loading} size="lg" icon={!loading ? <ArrowRight size={18} /> : undefined}>
              {isSignup ? 'إنشاء الحساب' : 'تسجيل الدخول'}
            </Button>
          </form>

          <div className="mt-4 text-center text-sm text-gray-400">
            {isSignup ? (
              <>
                لديك حساب بالفعل؟{' '}
                <button onClick={() => navigate('login')} className="text-neon-green hover:underline font-medium">
                  تسجيل الدخول
                </button>
              </>
            ) : (
              <>
                ليس لديك حساب؟{' '}
                <button onClick={() => navigate('signup')} className="text-neon-green hover:underline font-medium">
                  إنشاء حساب مجاني
                </button>
              </>
            )}
          </div>
        </Card>

        <div className="text-center mt-4">
          <button onClick={() => navigate('home')} className="text-sm text-gray-500 hover:text-gray-300 transition-colors">
            العودة للرئيسية
          </button>
        </div>
      </div>
    </div>
  );
}
