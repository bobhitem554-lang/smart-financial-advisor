import { AuthProvider, useAuth } from '@/lib/auth';
import { RouterProvider, useRouter } from '@/lib/router';
import { Layout } from '@/components/Layout';
import { FullPageSpinner } from '@/components/Spinner';
import { HomePage } from '@/pages/HomePage';
import { AuthPage } from '@/pages/AuthPage';
import { FeasibilityStudyPage } from '@/pages/FeasibilityStudyPage';
import { FinancialAnalysisPage } from '@/pages/FinancialAnalysisPage';
import { FileUploadPage } from '@/pages/FileUploadPage';
import { AdvisorPage } from '@/pages/AdvisorPage';
import { CalculatorPage } from '@/pages/CalculatorPage';
import { ScenariosPage } from '@/pages/ScenariosPage';
import { ProfilePage } from '@/pages/ProfilePage';
import { AdminPage } from '@/pages/AdminPage';
import { PlansPage } from '@/pages/PlansPage';
import type { Route } from '@/lib/router';

function PageRouter() {
  const { route, navigate } = useRouter();
  const { user, loading } = useAuth();

  if (loading) {
    return <FullPageSpinner message="جاري التحميل..." />;
  }

  // Auth pages render without layout
  if (route === 'login') return <AuthPage mode="login" />;
  if (route === 'signup') return <AuthPage mode="signup" />;

  // Routes that require auth
  const authRequired: Route[] = ['profile', 'admin'];
  if (authRequired.includes(route) && !user) {
    navigate('login');
    return <FullPageSpinner message="جاري التحويل..." />;
  }

  // Admin-only route
  if (route === 'admin') {
    return (
      <Layout>
        <AdminPage />
      </Layout>
    );
  }

  const pages: Record<Route, React.ReactNode> = {
    home: <HomePage />,
    feasibility: <FeasibilityStudyPage />,
    financial: <FinancialAnalysisPage />,
    files: <FileUploadPage />,
    advisor: <AdvisorPage />,
    calculator: <CalculatorPage />,
    scenarios: <ScenariosPage />,
    profile: <ProfilePage />,
    admin: <AdminPage />,
    plans: <PlansPage />,
    login: null,
    signup: null,
  };

  return <Layout>{pages[route]}</Layout>;
}

export default function App() {
  return (
    <AuthProvider>
      <RouterProvider>
        <PageRouter />
      </RouterProvider>
    </AuthProvider>
  );
}
