import { supabase } from './supabase';
import type { UsageTracking } from './types';

export async function trackUsage(userId: string, action: UsageTracking['action']): Promise<void> {
  await supabase.from('usage_tracking').insert({ user_id: userId, action });
}

export async function getUsageCount(userId: string, action: UsageTracking['action']): Promise<number> {
  const period = new Date().toISOString().slice(0, 7);
  const { count, error } = await supabase
    .from('usage_tracking')
    .select('*', { count: 'exact', head: true })
    .eq('user_id', userId)
    .eq('action', action)
    .eq('period', period);
  if (error) return 0;
  return count ?? 0;
}

export function getExpiryDate(): string {
  return new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
}

export function isExpired(expiresAt: string): boolean {
  return new Date(expiresAt).getTime() < Date.now();
}

export function timeRemaining(expiresAt: string): string {
  const remaining = new Date(expiresAt).getTime() - Date.now();
  if (remaining <= 0) return 'منتهي الصلاحية';
  const hours = Math.floor(remaining / (60 * 60 * 1000));
  const minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
  if (hours > 0) return `متبقي ${hours} ساعة و ${minutes} دقيقة`;
  return `متبقي ${minutes} دقيقة`;
}
