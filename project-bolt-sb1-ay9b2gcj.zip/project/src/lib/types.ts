export type Plan = 'free' | 'premium';
export type UserRole = 'user' | 'admin';
export type FileStatus = 'pending' | 'processing' | 'completed' | 'failed';
export type AdvisorContextType = 'general' | 'feasibility' | 'financial' | 'file';

export interface Profile {
  id: string;
  email: string;
  full_name: string;
  plan: Plan;
  role: UserRole;
  avatar_url: string;
  created_at: string;
  updated_at: string;
}

export interface PlanLimits {
  plan: Plan;
  max_feasibility_studies: number;
  max_financial_analyses: number;
  max_file_uploads: number;
  max_advisor_messages: number;
  advanced_analysis: boolean;
  advanced_pdf: boolean;
  scenarios_enabled: boolean;
  file_analysis_enabled: boolean;
  updated_at: string;
}

export interface FeasibilityStudy {
  id: string;
  user_id: string;
  project_name: string;
  project_type: string;
  country: string;
  city: string;
  currency: string;
  capital: number;
  setup_costs: number;
  monthly_expenses: number;
  product_cost: number;
  employee_count: number;
  salaries: number;
  rent: number;
  marketing: number;
  expected_monthly_revenue: number;
  expected_customers: number;
  product_price: number;
  additional_info: string;
  results: FeasibilityResults | Record<string, never>;
  created_at: string;
  expires_at: string;
}

export interface FeasibilityResults {
  summary: string;
  marketAnalysis: string;
  totalMonthlyCosts: number;
  monthlyRevenue: number;
  netProfit: number;
  profitMargin: number;
  breakEvenPoint: number;
  paybackPeriod: number;
  forecasts: { month: number; revenue: number; expenses: number; profit: number }[];
  strengths: string[];
  weaknesses: string[];
  risks: string[];
  opportunities: string[];
  recommendations: string[];
}

export interface FinancialAnalysis {
  id: string;
  user_id: string;
  title: string;
  revenue: number;
  expenses: number;
  fixed_expenses: number;
  variable_expenses: number;
  assets: number;
  liabilities: number;
  cash_inflow: number;
  cash_outflow: number;
  results: FinancialResults | Record<string, never>;
  created_at: string;
  expires_at: string;
}

export interface FinancialResults {
  netProfit: number;
  profitMargin: number;
  breakEvenRevenue: number;
  breakEvenUnits: number;
  contributionMargin: number;
  contributionMarginRatio: number;
  netCashFlow: number;
  currentRatio: number;
  debtToAssets: number;
  roa: number;
  fixedCostRatio: number;
  variableCostRatio: number;
  monthlyBurnRate: number;
  runway: number;
  charts: {
    revenueVsExpenses: { label: string; value: number }[];
    costBreakdown: { label: string; value: number }[];
    cashFlow: { label: string; value: number }[];
    assetsLiabilities: { label: string; value: number }[];
  };
}

export interface FileUpload {
  id: string;
  user_id: string;
  file_name: string;
  file_type: string;
  file_size: number;
  extracted_data: Record<string, unknown>;
  analysis_result: Record<string, unknown>;
  status: FileStatus;
  created_at: string;
  expires_at: string;
}

export interface AdvisorMessage {
  role: 'user' | 'advisor';
  content: string;
  timestamp: string;
}

export interface AdvisorSession {
  id: string;
  user_id: string;
  context_type: AdvisorContextType;
  context_id: string | null;
  messages: AdvisorMessage[];
  message_count: number;
  created_at: string;
  expires_at: string;
}

export interface UsageTracking {
  id: string;
  user_id: string;
  action: 'feasibility_study' | 'financial_analysis' | 'file_upload' | 'advisor_message' | 'pdf_export';
  period: string;
  created_at: string;
}

export interface AppSettings {
  id: number;
  app_name: string;
  app_tagline: string;
  contact_email: string;
  maintenance_mode: boolean;
  updated_at: string;
}

export interface FeasibilityInput {
  project_name: string;
  project_type: string;
  country: string;
  city: string;
  currency: string;
  capital: number;
  setup_costs: number;
  monthly_expenses: number;
  product_cost: number;
  employee_count: number;
  salaries: number;
  rent: number;
  marketing: number;
  expected_monthly_revenue: number;
  expected_customers: number;
  product_price: number;
  additional_info: string;
}

export interface FinancialInput {
  title: string;
  revenue: number;
  expenses: number;
  fixed_expenses: number;
  variable_expenses: number;
  assets: number;
  liabilities: number;
  cash_inflow: number;
  cash_outflow: number;
}

export interface ScenarioData {
  name: string;
  label: string;
  revenueAdjustment: number;
  expenseAdjustment: number;
  revenue: number;
  expenses: number;
  profit: number;
  cashFlow: number;
  paybackPeriod: number;
  color: string;
}

export interface Database {
  public: {
    Tables: {
      profiles: { Row: Profile; Insert: Record<string, unknown>; Update: Partial<Profile> };
      plan_limits: { Row: PlanLimits; Insert: Record<string, unknown>; Update: Partial<PlanLimits> };
      feasibility_studies: { Row: FeasibilityStudy; Insert: Record<string, unknown>; Update: Partial<FeasibilityStudy> };
      financial_analyses: { Row: FinancialAnalysis; Insert: Record<string, unknown>; Update: Partial<FinancialAnalysis> };
      file_uploads: { Row: FileUpload; Insert: Record<string, unknown>; Update: Partial<FileUpload> };
      advisor_sessions: { Row: AdvisorSession; Insert: Record<string, unknown>; Update: Partial<AdvisorSession> };
      usage_tracking: { Row: UsageTracking; Insert: Record<string, unknown>; Update: Partial<UsageTracking> };
      app_settings: { Row: AppSettings; Insert: Record<string, unknown>; Update: Partial<AppSettings> };
    };
  };
}
