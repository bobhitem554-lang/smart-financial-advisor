import type { FeasibilityResults, FinancialResults, AdvisorMessage } from './types';
import { formatCurrency, formatPercent, formatNumber } from './financial';

interface AdvisorContext {
  type: 'general' | 'feasibility' | 'financial' | 'file';
  feasibility?: FeasibilityResults & { project_name: string; currency: string; capital: number; setup_costs: number; expected_customers: number };
  financial?: FinancialResults & { title: string };
  fileData?: Record<string, unknown>;
}

export function generateAdvisorResponse(question: string, context: AdvisorContext): string {
  const q = question.trim().toLowerCase();

  if (context.type === 'feasibility' && context.feasibility) {
    return feasibilityResponse(q, question, context.feasibility);
  }

  if (context.type === 'financial' && context.financial) {
    return financialResponse(q, question, context.financial);
  }

  if (context.type === 'file' && context.fileData) {
    return fileResponse(q, question, context.fileData);
  }

  return generalResponse(q, question);
}

function feasibilityResponse(q: string, original: string, f: AdvisorContext['feasibility']): string {
  if (!f) return 'لا توجد بيانات كافية للإجابة.';

  const c = f.currency || 'ريال';

  if (q.includes('مربح') || q.includes('ربح') || q.includes('هل مشروع')) {
    if (f.netProfit > 0) {
      return `نعم، مشروع "${f.project_name}" يبدو مربحاً. صافي الربح الشهري المتوقع هو ${formatCurrency(f.netProfit, c)} بهامش ربح ${formatPercent(f.profitMargin)}. ` +
        `${f.paybackPeriod > 0 ? `فترة استرداد رأس المال تقدر بـ ${formatNumber(f.paybackPeriod)} سنة.` : ''} ` +
        `ومع ذلك، يجب الانتباه إلى المخاطر المحتملة مثل ${f.risks[0] || 'تقلبات السوق'}.`;
    }
    return `بناءً على البيانات الحالية، مشروع "${f.project_name}" ${f.netProfit < 0 ? 'يعاني من خسارة' : 'لا يحقق ربحاً واضحاً'}. ` +
      `التكاليف الشهرية تبلغ ${formatCurrency(f.totalMonthlyCosts, c)} والإيرادات ${formatCurrency(f.monthlyRevenue, c)}. ` +
      `أنصح بمراجعة التكاليف أو زيادة الإيرادات قبل المضي قدماً. ${f.recommendations[0] || ''}`;
  }

  if (q.includes('انخفض') || q.includes('انخفاض') || q.includes('مبيعات') || q.includes('سينا')) {
    const declineMatch = original.match(/(\d+)%?/);
    const decline = declineMatch ? parseInt(declineMatch[1]) : 20;
    const newRevenue = f.monthlyRevenue * (1 - decline / 100);
    const newProfit = newRevenue - f.totalMonthlyCosts;
    return `إذا انخفضت المبيعات بنسبة ${decline}٪، ستتغير الإيرادات إلى ${formatCurrency(newRevenue, c)}. ` +
      `${newProfit > 0 ? `سيظل المشروع يحقق ربحاً قدره ${formatCurrency(newProfit, c)}، لكن هامش الربح سينخفض إلى ${formatPercent((newProfit / newRevenue) * 100)}.` : `سيتحول المشروع إلى خسارة قدرها ${formatCurrency(Math.abs(newProfit), c)}. في هذه الحالة، يجب تخفيض التكاليف أو زيادة الأسعار.`}`;
  }

  if (q.includes('مشكلة') || q.includes('خطر') || q.includes('مخاطر')) {
    return `أكبر المخاطر في هذا المشروع:\n${f.risks.map((r, i) => `${i + 1}. ${r}`).join('\n')}\n\n` +
      `نقاط الضعف الرئيسية:\n${f.weaknesses.map((w, i) => `${i + 1}. ${w}`).join('\n')}`;
  }

  if (q.includes('رأس المال') || q.includes('رأس مال') || q.includes('يكفي') || q.includes('كافي')) {
    const totalInvestment = f.capital + f.setup_costs;
    if (f.capital >= totalInvestment * 0.7) {
      return `رأس المال الحالي (${formatCurrency(f.capital, c)}) يغطي ${formatPercent((f.capital / totalInvestment) * 100)} من إجمالي الاستثمار المتوقع (${formatCurrency(totalInvestment, c)}). يبدو كافياً، لكن أنصح ببناء احتياطي نقدي للسناريو المتشائم.`;
    }
    return `رأس المال الحالي (${formatCurrency(f.capital, c)}) يغطي ${formatPercent((f.capital / totalInvestment) * 100)} من إجمالي الاستثمار المتوقع (${formatCurrency(totalInvestment, c)}). قد لا يكون كافياً. أنصح بزيادة رأس المال أو تخفيض التكاليف الأولية. ${f.recommendations[0] || ''}`;
  }

  if (q.includes('هامش') || (q.includes('ربح') && q.includes('زيد'))) {
    return `لزيادة هامش الربح الحالي (${formatPercent(f.profitMargin)}):\n${f.recommendations.slice(0, 4).map((r, i) => `${i + 1}. ${r}`).join('\n')}`;
  }

  if (q.includes('خفض') || q.includes('تخفيض') || q.includes('مصاريف') || q.includes('تكاليف')) {
    return `لخفض المصاريف، أنصح بمراجعة التكاليف التالية:\n${f.weaknesses.filter((w) => w.includes('رواتب') || w.includes('إيجار') || w.includes('تكاليف')).map((w) => `• ${w}`).join('\n')}\n` +
      `كما يمكن:\n• التفاوض على أسعار أفضل مع الموردين\n• أتمتة العمليات لتقليل تكاليف العمالة\n• تقليل المصاريف غير الأساسية\n• استخدام التسويق الرقمي بدلاً من التقليدي`;
  }

  if (q.includes('توصية') || q.includes('نصيحة') || q.includes('ماذا تنصح')) {
    return `توصياتي للمشروع "${f.project_name}":\n${f.recommendations.map((r, i) => `${i + 1}. ${r}`).join('\n')}`;
  }

  if (q.includes('فرص') || q.includes('فرصة') || q.includes('توسع')) {
    return `الفرص المتاحة:\n${f.opportunities.map((o, i) => `${i + 1}. ${o}`).join('\n')}`;
  }

  if (q.includes('نقطة تعادل') || q.includes('تعادل')) {
    return `نقطة التعادل هي ${formatNumber(f.breakEvenPoint)} وحدة مبيعات شهرياً. ` +
      `أي مبيعات أقل من هذا الرقم تعني خسارة، وأي مبيعات أعلى تعني ربح. ` +
      `الإيراد عند نقطة التعادل هو ${formatCurrency(f.breakEvenPoint * (f.monthlyRevenue / Math.max(f.expected_customers, 1)), c)}.`;
  }

  if (q.includes('توقعات') || q.includes('مستقبل') || q.includes('توقع')) {
    const month6 = f.forecasts[5];
    const month12 = f.forecasts[11];
    return `التوقعات للـ12 شهراً القادمة (بنسبة نمو 3٪ شهرياً):\n` +
      `• الشهر 6: إيرادات ${formatCurrency(month6.revenue, c)}، ربح ${formatCurrency(month6.profit, c)}\n` +
      `• الشهر 12: إيرادات ${formatCurrency(month12.revenue, c)}، ربح ${formatCurrency(month12.profit, c)}\n` +
      `النمو التراكمي المتوقع في الإيرادات ${formatPercent(((month12.revenue / f.monthlyRevenue) - 1) * 100)}.`;
  }

  return `بناءً على تحليل مشروع "${f.project_name}":\n` +
    `• الإيرادات الشهرية: ${formatCurrency(f.monthlyRevenue, c)}\n` +
    `• التكاليف الشهرية: ${formatCurrency(f.totalMonthlyCosts, c)}\n` +
    `• صافي الربح: ${formatCurrency(f.netProfit, c)}\n` +
    `• هامش الربح: ${formatPercent(f.profitMargin)}\n` +
    `${f.paybackPeriod > 0 ? `• فترة استرداد رأس المال: ${formatNumber(f.paybackPeriod)} سنة\n` : ''}` +
    `\nيمكنك سؤالي عن: الربحية، المخاطر، التوصيات، الفرص، نقطة التعادل، التوقعات المستقبلية، أو أي سؤال آخر.`;
}

function financialResponse(q: string, _original: string, f: AdvisorContext['financial']): string {
  if (!f) return 'لا توجد بيانات كافية للإجابة.';

  if (q.includes('ربح') || q.includes('أداء')) {
    return `تحليل "${f.title}":\n• صافي الربح: ${formatCurrency(f.netProfit)}\n• هامش الربح: ${formatPercent(f.profitMargin)}\n` +
      `${f.netProfit > 0 ? 'الأداء المالي إيجابي.' : 'الأداء المالي يحتاج تحسين، هناك خسارة.'}`;
  }

  if (q.includes('تعادل')) {
    return `نقطة التعادل بالإيرادات: ${formatCurrency(f.breakEvenRevenue)}\nنقطة التعادل بالوحدات: ${formatNumber(f.breakEvenUnits)} وحدة.\n` +
      `هامش المساهمة: ${formatPercent(f.contributionMarginRatio)}`;
  }

  if (q.includes('تدفق') || q.includes('نقدي')) {
    return `صافي التدفق النقدي: ${formatCurrency(f.netCashFlow)}\n${f.netCashFlow > 0 ? 'التدفق النقدي موجب، وهو مؤشر جيد.' : 'التدفق النقدي سالب، يجب مراجعة السيولة.'}`;
  }

  if (q.includes('أصول') || q.includes('خصوم') || q.includes('مديونية')) {
    return `نسبة الدين إلى الأصول: ${formatPercent(f.debtToAssets)}\nالنسبة الجارية: ${formatNumber(f.currentRatio)}\n` +
      `${f.debtToAssets > 50 ? 'مستوى المديونية مرتفع.' : 'مستوى المديونية ضمن حدود مقبولة.'}`;
  }

  return `تحليل "${f.title}":\n• صافي الربح: ${formatCurrency(f.netProfit)}\n• هامش الربح: ${formatPercent(f.profitMargin)}\n• صافي التدفق النقدي: ${formatCurrency(f.netCashFlow)}\n• العائد على الأصول: ${formatPercent(f.roa)}\n\nيمكنك سؤالي عن: الربحية، نقطة التعادل، التدفقات النقدية، الأصول والخصوم، أو أي سؤال آخر.`;
}

function fileResponse(q: string, _original: string, data: Record<string, unknown>): string {
  const summary = data['summary'] as string || 'تم استخراج البيانات بنجاح.';
  if (q.includes('ملخص') || q.includes('لخص')) {
    return `ملخص الملف المرفوع:\n${summary}`;
  }
  return `بناءً على البيانات المستخرجة من الملف:\n${summary}\n\nيمكنك سؤالي عن تفاصيل محددة في الأرقام أو طلب تحليل أعمق.`;
}

function generalResponse(q: string, original: string): string {
  if (q.includes('مرحب') || q.includes('السلام') || q.includes('هاي')) {
    return 'مرحباً بك! أنا مستشارك المالي الذكي. يمكنني مساعدتك في تحليل جدوى المشاريع، التحليل المالي، السيناريوهات، والمزيد. كيف يمكنني مساعدتك اليوم؟';
  }

  if (q.includes('كيف') && (q.includes('ابدأ') || q.includes('أبدأ') || q.includes('استخدام'))) {
    return 'للبدء، يمكنك:\n1. إنشاء دراسة جدوى جديدة لإجراء تحليل كامل لمشروعك\n2. إجراء تحليل مالي لإيراداتك ومصروفاتك\n3. رفع ملف مالي لاستخراج وتحليل البيانات\n4. استخدام حاسبة الأرباح والتكاليف\nاختر ما يناسبك من القائمة الرئيسية!';
  }

  if (q.includes('هامش الربح') || q.includes('how to increase profit')) {
    return 'لزيادة هامش الربح، أنصح بـ:\n1. رفع أسعار المنتجات/الخدمات تدريجياً\n2. تخفيض التكاليف المتغيرة عبر التفاوض مع الموردين\n3. تحسين كفاءة العمليات لتقليل الهدر\n4. التركيز على المنتجات/الخدمات ذات الهامش الأعلى\n5. استخدام التكنولوجيا لأتمتة المهام المتكررة';
  }

  if (q.includes('نقطة تعادل')) {
    return 'نقطة التعادل هي الحد الذي تكون فيه الإيرادات مساوية للتكاليف (لا ربح ولا خسارة). تحسب بقسمة التكاليف الثابتة على هامش المساهمة. أي مبيعات فوق نقطة التعادل تعني ربحاً، وأي مبيعات تحتها تعني خسارة.';
  }

  if (original.length > 0) {
    return `سؤال ممتاز! لإعطاء إجابة دقيقة ومفصلة، أنصحك بإنشاء دراسة جدوى أو تحليل مالي أولاً. بعد إدخال بيانات مشروعك، سأكون قادراً على تقديم تحليل تفصيلي مبنى على أرقامك الفعلية.\n\nيمكنك أيضاً سؤالي أسئلة عامة مثل:\n• كيف أزيد هامش الربح؟\n• ما هي نقطة التعادل؟\n• كيف أبدأ؟`;
  }

  return 'مرحباً! أنا مستشارك المالي الذكي. كيف يمكنني مساعدتك اليوم؟';
}

export function getQuickQuestions(contextType: AdvisorContext['type']): string[] {
  if (contextType === 'feasibility') {
    return [
      'هل مشروعي مربح؟',
      'ماذا يحدث إذا انخفضت المبيعات 20٪؟',
      'ما أكبر مشكلة في هذا المشروع؟',
      'هل رأس المال يكفي؟',
      'كيف أزيد هامش الربح؟',
      'ما المصاريف التي يجب تخفيضها؟',
    ];
  }
  if (contextType === 'financial') {
    return [
      'كيف هو أداء الشركة المالي؟',
      'ما هي نقطة التعادل؟',
      'كيف تبدو التدفقات النقدية؟',
      'ما مستوى المديونية؟',
    ];
  }
  if (contextType === 'file') {
    return [
      'لخص لي محتوى الملف',
      'ما أهم الأرقام في التقرير؟',
    ];
  }
  return [
    'كيف أبدأ؟',
    'كيف أزيد هامش الربح؟',
    'ما هي نقطة التعادل؟',
  ];
}

export function buildContextFromMessages(messages: AdvisorMessage[]): string {
  return messages.map((m) => `${m.role === 'user' ? 'المستخدم' : 'المستشار'}: ${m.content}`).join('\n');
}
