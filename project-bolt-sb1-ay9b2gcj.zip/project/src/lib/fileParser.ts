export interface ParsedFileData {
  summary: string;
  numbers: { label: string; value: number }[];
  tables: { headers: string[]; rows: string[][] }[];
  rawText: string;
  fileType: string;
  success: boolean;
  error?: string;
}

const ACCEPTED_TYPES = [
  'application/pdf',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  'application/vnd.ms-excel',
  'application/msword',
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
  'text/csv',
  'text/plain',
  'image/png',
  'image/jpeg',
  'image/jpg',
  'image/webp',
];

const ACCEPTED_EXTENSIONS = ['.pdf', '.xlsx', '.xls', '.docx', '.doc', '.csv', '.txt', '.png', '.jpg', '.jpeg', '.webp'];

export function isAcceptedFile(file: File): boolean {
  if (ACCEPTED_TYPES.includes(file.type)) return true;
  const ext = '.' + (file.name.split('.').pop() || '').toLowerCase();
  return ACCEPTED_EXTENSIONS.includes(ext);
}

export async function parseFile(file: File): Promise<ParsedFileData> {
  const ext = (file.name.split('.').pop() || '').toLowerCase();
  const fileType = file.type || ext;

  try {
    if (ext === 'csv' || ext === 'txt' || file.type === 'text/csv' || file.type === 'text/plain') {
      return parseCSV(await file.text(), fileType);
    }

    if (ext === 'pdf' || file.type === 'application/pdf') {
      return await parsePDF(file, fileType);
    }

    if (ext === 'xlsx' || ext === 'xls' || file.type.includes('spreadsheet') || file.type.includes('excel')) {
      return await parseSpreadsheet(file, fileType);
    }

    if (ext === 'docx' || ext === 'doc' || file.type.includes('word')) {
      return await parseWord(file, fileType);
    }

    if (ext === 'png' || ext === 'jpg' || ext === 'jpeg' || ext === 'webp' || file.type.startsWith('image/')) {
      return parseImage(file.name, fileType);
    }

    return {
      summary: '',
      numbers: [],
      tables: [],
      rawText: '',
      fileType,
      success: false,
      error: 'نوع الملف غير مدعوم. الأنواع المدعومة: PDF, Excel, Word, CSV, صور.',
    };
  } catch {
    return {
      summary: '',
      numbers: [],
      tables: [],
      rawText: '',
      fileType,
      success: false,
      error: 'حدث خطأ أثناء قراءة الملف. تأكد من أن الملف غير تالف وحاول مرة أخرى.',
    };
  }
}

function parseCSV(text: string, fileType: string): ParsedFileData {
  const lines = text.trim().split(/\r?\n/).filter((l) => l.trim());
  if (lines.length === 0) {
    return { summary: '', numbers: [], tables: [], rawText: '', fileType, success: false, error: 'الملف فارغ.' };
  }

  const headers = parseCSVLine(lines[0]);
  const rows = lines.slice(1).map(parseCSVLine);

  const numbers: { label: string; value: number }[] = [];
  for (let col = 0; col < headers.length; col++) {
    for (const row of rows) {
      const val = parseFloat((row[col] || '').replace(/[^0-9.-]/g, ''));
      if (!isNaN(val) && val !== 0) {
        numbers.push({ label: `${headers[col]} - ${row[0] || 'صف'}`, value: val });
      }
    }
  }

  const summary = `تم استخراج ${rows.length} صف و ${headers.length} عمود من الملف. ` +
    (numbers.length > 0 ? `تم العثور على ${numbers.length} قيمة رقمية. الأعمدة: ${headers.join('، ')}.` : '');

  return {
    summary,
    numbers: numbers.slice(0, 50),
    tables: [{ headers, rows: rows.slice(0, 20) }],
    rawText: text.slice(0, 5000),
    fileType,
    success: true,
  };
}

function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

async function parsePDF(file: File, fileType: string): Promise<ParsedFileData> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    const text = extractPDFText(bytes);

    if (!text || text.trim().length < 10) {
      return {
        summary: '',
        numbers: [],
        tables: [],
        rawText: '',
        fileType,
        success: false,
        error: 'لم يتمكن النظام من استخراج نص من ملف PDF. قد يكون الملف ممسوحاً ضوئياً (صور) أو محمياً. تأكد من أن الملف يحتوي على نص قابل للقراءة.',
      };
    }

    const numbers = extractNumbers(text);
    const summary = `تم استخراج النص من ملف PDF (${text.length} حرف). ` +
      (numbers.length > 0 ? `تم العثور على ${numbers.length} قيمة رقمية.` : 'لم يتم العثور على أرقام واضحة.');

    return {
      summary,
      numbers: numbers.slice(0, 50),
      tables: [],
      rawText: text.slice(0, 5000),
      fileType,
      success: true,
    };
  } catch {
    return {
      summary: '',
      numbers: [],
      tables: [],
      rawText: '',
      fileType,
      success: false,
      error: 'تعذّر قراءة ملف PDF. تأكد من أن الملف غير تالف.',
    };
  }
}

function extractPDFText(bytes: Uint8Array): string {
  let text = '';
  try {
    const decoder = new TextDecoder('latin1');
    const raw = decoder.decode(bytes);
    const textMatches = raw.match(/\(([^()\\]{2,})\)/g);
    if (textMatches) {
      text = textMatches.map((m) => m.slice(1, -1)).join(' ');
    }
    const tjMatches = raw.match(/\[([^\]]+)\]\s*TJ/g);
    if (tjMatches) {
      text += ' ' + tjMatches.map((m) => {
        const inner = m.match(/\(([^()\\]*)\)/g);
        return inner ? inner.map((x) => x.slice(1, -1)).join('') : '';
      }).join(' ');
    }
  } catch {
    // ignore
  }
  return text.trim();
}

async function parseSpreadsheet(file: File, fileType: string): Promise<ParsedFileData> {
  return {
    summary: 'تم رفع ملف جدول بنجاح. لاستخراج البيانات بشكل كامل، يرجى استخدام صيغة CSV التي يدعمها النظام مباشرةً، أو رفع ملف PDF يحتوي على نفس البيانات.',
    numbers: [],
    tables: [],
    rawText: '',
    fileType,
    success: true,
  };
}

async function parseWord(file: File, fileType: string): Promise<ParsedFileData> {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const bytes = new Uint8Array(arrayBuffer);
    const decoder = new TextDecoder('latin1');
    const raw = decoder.decode(bytes);
    const textMatches = raw.match(/<w:t[^>]*>([^<]+)<\/w:t>/g);
    let text = '';
    if (textMatches) {
      text = textMatches.map((m) => {
        const content = m.replace(/<[^>]+>/g, '');
        return content;
      }).join(' ');
    }

    if (!text || text.trim().length < 5) {
      return {
        summary: 'تم رفع ملف Word بنجاح، لكن لم يتم استخراج نص كافٍ. تأكد من أن الملف يحتوي على محتوى نصي.',
        numbers: [],
        tables: [],
        rawText: '',
        fileType,
        success: true,
      };
    }

    const numbers = extractNumbers(text);
    const summary = `تم استخراج النص من ملف Word (${text.length} حرف). ` +
      (numbers.length > 0 ? `تم العثور على ${numbers.length} قيمة رقمية.` : '');

    return {
      summary,
      numbers: numbers.slice(0, 50),
      tables: [],
      rawText: text.slice(0, 5000),
      fileType,
      success: true,
    };
  } catch {
    return {
      summary: '',
      numbers: [],
      tables: [],
      rawText: '',
      fileType,
      success: false,
      error: 'تعذّر قراءة ملف Word. تأكد من أن الملف غير تالف.',
    };
  }
}

function parseImage(fileName: string, fileType: string): ParsedFileData {
  return {
    summary: 'تم رفع الصورة بنجاح. استخراج النص من الصور (OCR) غير متاح حالياً. يرجى رفع الملف بصيغة نصية (PDF، Word، CSV) للحصول على تحليل أوسع.',
    numbers: [],
    tables: [],
    rawText: '',
    fileType,
    success: true,
  };
}

function extractNumbers(text: string): { label: string; value: number }[] {
  const numbers: { label: string; value: number }[] = [];
  const lines = text.split(/\n/);
  const arabicNumPattern = /([0-9][0-9,.]*)/g;

  for (const line of lines) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const matches = [...trimmed.matchAll(arabicNumPattern)];
    for (const match of matches) {
      const rawValue = match[1].replace(/,/g, '');
      const value = parseFloat(rawValue);
      if (!isNaN(value) && Math.abs(value) > 0) {
        const label = trimmed.replace(match[0], '').trim().slice(0, 50) || 'قيمة';
        numbers.push({ label, value });
      }
    }
  }
  return numbers;
}
