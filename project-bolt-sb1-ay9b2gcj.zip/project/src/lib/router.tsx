import { createContext, useContext, useEffect, useState, useCallback, type ReactNode } from 'react';

export type Route =
  | 'home'
  | 'feasibility'
  | 'financial'
  | 'files'
  | 'advisor'
  | 'calculator'
  | 'scenarios'
  | 'login'
  | 'signup'
  | 'profile'
  | 'admin'
  | 'plans';

interface RouterContextValue {
  route: Route;
  params: Record<string, string>;
  navigate: (route: Route, params?: Record<string, string>) => void;
}

const RouterContext = createContext<RouterContextValue | undefined>(undefined);

function parseHash(): { route: Route; params: Record<string, string> } {
  const hash = window.location.hash.slice(1) || '/';
  const [path, query] = hash.split('?');
  const segments = path.split('/').filter(Boolean);
  const route = (segments[0] || 'home') as Route;
  const params: Record<string, string> = {};
  if (query) {
    new URLSearchParams(query).forEach((v, k) => { params[k] = v; });
  }
  // Support /advisor?context=feasibility&id=xxx
  if (segments[1]) {
    params[segments[0]] = segments.slice(1).join('/');
  }
  return { route, params };
}

const validRoutes: Route[] = [
  'home', 'feasibility', 'financial', 'files', 'advisor', 'calculator',
  'scenarios', 'login', 'signup', 'profile', 'admin', 'plans',
];

export function RouterProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState(parseHash());

  useEffect(() => {
    const onHashChange = () => {
      const parsed = parseHash();
      if (validRoutes.includes(parsed.route)) {
        setState(parsed);
      } else {
        setState({ route: 'home', params: {} });
      }
      window.scrollTo(0, 0);
    };
    window.addEventListener('hashchange', onHashChange);
    return () => window.removeEventListener('hashchange', onHashChange);
  }, []);

  const navigate = useCallback((route: Route, params?: Record<string, string>) => {
    let hash = `/${route}`;
    if (params) {
      const search = new URLSearchParams(params).toString();
      if (search) hash += `?${search}`;
    }
    window.location.hash = hash;
  }, []);

  return (
    <RouterContext.Provider value={{ route: state.route, params: state.params, navigate }}>
      {children}
    </RouterContext.Provider>
  );
}

export function useRouter(): RouterContextValue {
  const ctx = useContext(RouterContext);
  if (!ctx) throw new Error('useRouter must be used within RouterProvider');
  return ctx;
}
