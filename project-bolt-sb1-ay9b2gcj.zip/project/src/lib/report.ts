import type { FeasibilityInput, FeasibilityResults, FinancialInput, FinancialResults, ScenarioData } from './types';
import { formatCurrency, formatPercent, formatNumber, calculateScenarios } from './financial';

interface ReportData {
  type: 'feasibility' | 'financial';
  projectName: string;
  projectType?: string;
  country?: string;
  city?: string;
  currency: string;
  input: FeasibilityInput | FinancialInput;
  results: FeasibilityResults | FinancialResults;
}

export function generateReport(data: ReportData): void {
  const win = window.open('', '_blank');
  if (!win) {
    alert('الرجاء السماح بالنوافذ المنبثقة لتنزيل التقرير');
    return;
  }

  const html = buildReportHTML(data);
  win.document.open();
  win.document.write(html);
  win.document.close();

  setTimeout(() => {
    win.focus();
    win.print();
  }, 500);
}

function buildReportHTML(data: ReportData): string {
  const { type, projectName, currency } = data;
  const now = new Date().toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });

  let body = '';

  if (type === 'feasibility') {
    body = buildFeasibilityBody(data);
  } else {
    body = buildFinancialBody(data);
  }

  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<title>تقرير ${type === 'feasibility' ? 'دراسة جدوى' : 'تحليل مالي'} - ${projectName}</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Cairo:wght@300;400;500;600;700;800&display=swap');
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body {
    font-family: 'Cairo', sans-serif;
    color: #1a3155;
    background: white;
    direction: rtl;
    padding: 40px;
    line-height: 1.6;
  }
  .header {
    text-align: center;
    padding: 30px 20px;
    border-bottom: 3px solid #00c853;
    margin-bottom: 30px;
  }
  .header h1 {
    color: #244070;
    font-size: 28px;
    margin-bottom: 5px;
  }
  .header p {
    color: #666;
    font-size: 14px;
  }
  .header .logo {
    display: inline-block;
    width: 50px; height: 50px;
    border-radius: 12px;
    background: linear-gradient(135deg, #00e676, #00c853);
    margin-bottom: 10px;
    text-align: center;
    line-height: 50px;
    color: white;
    font-size: 24px;
    font-weight: bold;
  }
  .section {
    margin-bottom: 25px;
    page-break-inside: avoid;
  }
  .section h2 {
    color: #244070;
    font-size: 18px;
    padding-bottom: 8px;
    border-bottom: 2px solid #e0e0e0;
    margin-bottom: 12px;
  }
  .section h3 {
    color: #335390;
    font-size: 15px;
    margin: 10px 0 8px;
  }
  .info-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 10px;
  }
  .info-item {
    padding: 8px 12px;
    background: #f5f7fa;
    border-radius: 8px;
    font-size: 13px;
  }
  .info-item strong { color: #244070; }
  .metrics-grid {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 10px;
    margin: 12px 0;
  }
  .metric-card {
    padding: 12px;
    border: 1px solid #e0e0e0;
    border-radius: 10px;
    text-align: center;
  }
  .metric-card .label { font-size: 11px; color: #666; margin-bottom: 4px; }
  .metric-card .value { font-size: 18px; font-weight: bold; color: #244070; }
  .metric-card.green .value { color: #00c853; }
  .metric-card.red .value { color: #d32f2f; }
  .metric-card.blue .value { color: #0091ea; }
  table {
    width: 100%;
    border-collapse: collapse;
    margin: 10px 0;
    font-size: 13px;
  }
  th, td {
    padding: 8px 12px;
    text-align: right;
    border-bottom: 1px solid #e0e0e0;
  }
  th {
    background: #f5f7fa;
    color: #244070;
    font-weight: 600;
  }
  .list { list-style: none; padding: 0; }
  .list li {
    padding: 6px 12px;
    margin-bottom: 4px;
    background: #f5f7fa;
    border-radius: 6px;
    font-size: 13px;
    border-right: 3px solid #00c853;
  }
  .list li.weak { border-right-color: #d32f2f; }
  .list li.risk { border-right-color: #f57c00; }
  .list li.opp { border-right-color: #0091ea; }
  .scenario-table th { background: #244070; color: white; }
  .scenario-table td { font-size: 12px; }
  .bar-chart { margin: 15px 0; }
  .bar-row { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
  .bar-row .label { width: 120px; font-size: 12px; }
  .bar-row .bar-bg { flex: 1; height: 24px; background: #f0f0f0; border-radius: 6px; overflow: hidden; }
  .bar-row .bar-fill { height: 100%; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-size: 11px; color: white; font-weight: 600; }
  .disclaimer {
    margin-top: 30px;
    padding: 15px 20px;
    background: #fff3e0;
    border: 1px solid #ffb74d;
    border-radius: 10px;
    font-size: 12px;
    color: #e65100;
    line-height: 1.8;
  }
  .footer {
    margin-top: 20px;
    text-align: center;
    font-size: 11px;
    color: #999;
    border-top: 1px solid #e0e0e0;
    padding-top: 10px;
  }
  @media print {
    body { padding: 20px; }
    .section { page-break-inside: avoid; }
  }
</style>
</head>
<body>
  <div class="header">
    <div class="logo">🤖</div>
    <h1>مستشارك المالي الذكي</h1>
    <p>${type === 'feasibility' ? 'تقرير دراسة جدوى' : 'تقرير تحليل مالي'} - ${projectName}</p>
    <p style="margin-top: 5px; font-size: 12px; color: #999;">تاريخ التقرير: ${now}</p>
  </div>
  ${body}
  <div class="disclaimer">
    <strong>تنبيه:</strong><br>
    هذا التحليل والتقدير تم إعداده من قبل فريق مستشارك المالي الذكي بناءً على البيانات والمعلومات المقدمة من المستخدم، ويُستخدم لأغراض التحليل والتقدير واتخاذ القرار المبدئي.
  </div>
  <div class="footer">
    مستشارك المالي الذكي — تقرير تم إنشاؤه تلقائياً في ${now}
  </div>
</body>
</html>`;
}

function buildFeasibilityBody(data: ReportData): string {
  const { input, results, currency, country, city, projectType } = data;
  const f = input as FeasibilityInput;
  const r = results as FeasibilityResults;
  const scenarios = calculateScenarios(r.monthlyRevenue, r.totalMonthlyCosts, f.capital + f.setup_costs, currency);

  return `
  <!-- Project Info -->
  <div class="section">
    <h2>معلومات المشروع</h2>
    <div class="info-grid">
      <div class="info-item"><strong>اسم المشروع:</strong> ${f.project_name}</div>
      <div class="info-item"><strong>نوع المشروع:</strong> ${projectType || 'غير محدد'}</div>
      <div class="info-item"><strong>الدولة:</strong> ${country || 'غير محدد'}</div>
      <div class="info-item"><strong>المدينة:</strong> ${city || 'غير محدد'}</div>
      <div class="info-item"><strong>العملة:</strong> ${currency}</div>
      <div class="info-item"><strong>رأس المال:</strong> ${formatCurrency(f.capital, currency)}</div>
    </div>
  </div>

  <!-- Executive Summary -->
  <div class="section">
    <h2>الملخص التنفيذي</h2>
    <p style="font-size: 13px; line-height: 1.8;">${r.summary}</p>
  </div>

  <!-- Key Metrics -->
  <div class="section">
    <h2>المؤشرات المالية الرئيسية</h2>
    <div class="metrics-grid">
      <div class="metric-card ${r.netProfit > 0 ? 'green' : 'red'}">
        <div class="label">صافي الربح الشهري</div>
        <div class="value">${formatCurrency(r.netProfit, currency)}</div>
      </div>
      <div class="metric-card ${r.profitMargin > 0 ? 'blue' : 'red'}">
        <div class="label">هامش الربح</div>
        <div class="value">${formatPercent(r.profitMargin)}</div>
      </div>
      <div class="metric-card">
        <div class="label">نقطة التعادل</div>
        <div class="value">${formatNumber(r.breakEvenPoint)}</div>
      </div>
      <div class="metric-card blue">
        <div class="label">فترة الاسترداد</div>
        <div class="value">${r.paybackPeriod > 0 ? formatNumber(r.paybackPeriod) + ' سنة' : '—'}</div>
      </div>
    </div>
  </div>

  <!-- Financial Data Table -->
  <div class="section">
    <h2>البيانات المالية</h2>
    <table>
      <tr><th>البند</th><th>القيمة الشهرية</th></tr>
      <tr><td>الإيرادات المتوقعة</td><td>${formatCurrency(r.monthlyRevenue, currency)}</td></tr>
      <tr><td>إجمالي التكاليف</td><td>${formatCurrency(r.totalMonthlyCosts, currency)}</td></tr>
      <tr><td>صافي الربح</td><td>${formatCurrency(r.netProfit, currency)}</td></tr>
      <tr><td>تكاليف التأسيس</td><td>${formatCurrency(f.setup_costs, currency)}</td></tr>
      <tr><td>الرواتب</td><td>${formatCurrency(f.salaries, currency)}</td></tr>
      <tr><td>الإيجار</td><td>${formatCurrency(f.rent, currency)}</td></tr>
      <tr><td>التسويق</td><td>${formatCurrency(f.marketing, currency)}</td></tr>
    </table>
  </div>

  <!-- Charts (CSS-based bars) -->
  <div class="section">
    <h2>الرسوم البيانية</h2>
    <div class="bar-chart">
      <div class="bar-row">
        <span class="label">الإيرادات</span>
        <div class="bar-bg"><div class="bar-fill" style="width: 100%; background: #00c853;">${formatCurrency(r.monthlyRevenue, currency)}</div></div>
      </div>
      <div class="bar-row">
        <span class="label">التكاليف</span>
        <div class="bar-bg"><div class="bar-fill" style="width: ${(r.totalMonthlyCosts / r.monthlyRevenue) * 100}%; background: #d32f2f;">${formatCurrency(r.totalMonthlyCosts, currency)}</div></div>
      </div>
      <div class="bar-row">
        <span class="label">صافي الربح</span>
        <div class="bar-bg"><div class="bar-fill" style="width: ${Math.max((r.netProfit / r.monthlyRevenue) * 100, 5)}%; background: #0091ea;">${formatCurrency(r.netProfit, currency)}</div></div>
      </div>
    </div>
  </div>

  <!-- Market Analysis -->
  <div class="section">
    <h2>تحليل السوق</h2>
    <p style="font-size: 13px; line-height: 1.8;">${r.marketAnalysis}</p>
  </div>

  <!-- Forecasts Table -->
  <div class="section">
    <h2>التوقعات المستقبلية (12 شهراً)</h2>
    <table>
      <tr><th>الشهر</th><th>الإيرادات</th><th>المصروفات</th><th>صافي الربح</th></tr>
      ${r.forecasts.map((fc) => `<tr><td>الشهر ${fc.month}</td><td>${formatCurrency(fc.revenue, currency)}</td><td>${formatCurrency(fc.expenses, currency)}</td><td>${formatCurrency(fc.profit, currency)}</td></tr>`).join('')}
    </table>
  </div>

  <!-- SWOT -->
  <div class="section">
    <h2>التحليل الرباعي (SWOT)</h2>
    <h3>نقاط القوة</h3>
    <ul class="list">${r.strengths.map((s) => `<li>${s}</li>`).join('')}</ul>
    <h3>نقاط الضعف</h3>
    <ul class="list">${r.weaknesses.map((w) => `<li class="weak">${w}</li>`).join('')}</ul>
    <h3>المخاطر</h3>
    <ul class="list">${r.risks.map((ri) => `<li class="risk">${ri}</li>`).join('')}</ul>
    <h3>الفرص</h3>
    <ul class="list">${r.opportunities.map((o) => `<li class="opp">${o}</li>`).join('')}</ul>
  </div>

  <!-- Scenarios -->
  <div class="section">
    <h2>تحليل السيناريوهات</h2>
    <table class="scenario-table">
      <tr><th>السيناريو</th><th>الإيرادات</th><th>المصروفات</th><th>الربح</th><th>التدفق النقدي</th><th>فترة الاسترداد</th></tr>
      ${scenarios.map((s) => `<tr style="background: ${s.color}11;">
        <td><strong style="color: ${s.color}">${s.label}</strong></td>
        <td>${formatCurrency(s.revenue, currency)}</td>
        <td>${formatCurrency(s.expenses, currency)}</td>
        <td>${formatCurrency(s.profit, currency)}</td>
        <td>${formatCurrency(s.cashFlow, currency)}</td>
        <td>${s.paybackPeriod > 0 ? formatNumber(s.paybackPeriod) + ' سنة' : '—'}</td>
      </tr>`).join('')}
    </table>
  </div>

  <!-- Recommendations -->
  <div class="section">
    <h2>التوصيات</h2>
    <ol class="list">
      ${r.recommendations.map((rec, i) => `<li><strong>${i + 1}.</strong> ${rec}</li>`).join('')}
    </ol>
  </div>

  <!-- Conclusion -->
  <div class="section">
    <h2>الخلاصة</h2>
    <p style="font-size: 13px; line-height: 1.8;">
      ${r.netProfit > 0
        ? `يظهر المشروع "${f.project_name}" جدوى اقتصادية واضحة بناءً على البيانات المقدمة، مع صافي ربح متوقع قدره ${formatCurrency(r.netProfit, currency)} شهرياً وهامش ربح ${formatPercent(r.profitMargin)}.`
        : `يتطلب المشروع "${f.project_name}" مراجعة جوهرية في التكاليف أو الإيرادات، حيث تشير الأرقام الحالية إلى ${r.netProfit < 0 ? 'خسارة' : 'هامش ربح ضئيل'}.`
      }
      ${r.paybackPeriod > 0 ? `فترة استرداد رأس المال تقدر بـ ${formatNumber(r.paybackPeriod)} سنة.` : ''}
      يُنصح بمراجعة دورية للأداء وضبط الخطة حسب النتائج الفعلية.
    </p>
  </div>
  `;
}

function buildFinancialBody(data: ReportData): string {
  const { input, results, currency } = data;
  const f = input as FinancialInput;
  const r = results as FinancialResults;
  const scenarios = calculateScenarios(f.revenue, f.expenses, f.assets, currency);

  return `
  <div class="section">
    <h2>معلومات التحليل</h2>
    <div class="info-grid">
      <div class="info-item"><strong>عنوان التحليل:</strong> ${f.title}</div>
      <div class="info-item"><strong>العملة:</strong> ${currency}</div>
    </div>
  </div>

  <div class="section">
    <h2>الملخص التنفيذي</h2>
    <p style="font-size: 13px; line-height: 1.8;">
      تحليل "${f.title}" يُظهر ${r.netProfit > 0 ? 'ربحاً صافياً' : 'خسارة'} قدرها ${formatCurrency(r.netProfit, currency)}
      بهامش ربح ${formatPercent(r.profitMargin)}. صافي التدفق النقدي ${formatCurrency(r.netCashFlow, currency)}.
      نسبة الدين إلى الأصول ${formatPercent(r.debtToAssets)}.
    </p>
  </div>

  <div class="section">
    <h2>المؤشرات المالية</h2>
    <div class="metrics-grid">
      <div class="metric-card ${r.netProfit > 0 ? 'green' : 'red'}"><div class="label">صافي الربح</div><div class="value">${formatCurrency(r.netProfit, currency)}</div></div>
      <div class="metric-card blue"><div class="label">هامش الربح</div><div class="value">${formatPercent(r.profitMargin)}</div></div>
      <div class="metric-card"><div class="label">نقطة التعادل</div><div class="value">${formatCurrency(r.breakEvenRevenue, currency)}</div></div>
      <div class="metric-card ${r.netCashFlow > 0 ? 'green' : 'red'}"><div class="label">التدفق النقدي</div><div class="value">${formatCurrency(r.netCashFlow, currency)}</div></div>
    </div>
    <div class="metrics-grid" style="margin-top: 10px;">
      <div class="metric-card"><div class="label">هامش المساهمة</div><div class="value">${formatPercent(r.contributionMarginRatio)}</div></div>
      <div class="metric-card"><div class="label">نسبة الدين للأصول</div><div class="value">${formatPercent(r.debtToAssets)}</div></div>
      <div class="metric-card"><div class="label">العائد على الأصول</div><div class="value">${formatPercent(r.roa)}</div></div>
      <div class="metric-card"><div class="label">النسبة الجارية</div><div class="value">${formatNumber(r.currentRatio)}</div></div>
    </div>
  </div>

  <div class="section">
    <h2>البيانات المالية</h2>
    <table>
      <tr><th>البند</th><th>القيمة</th></tr>
      <tr><td>الإيرادات</td><td>${formatCurrency(f.revenue, currency)}</td></tr>
      <tr><td>المصروفات</td><td>${formatCurrency(f.expenses, currency)}</td></tr>
      <tr><td>المصروفات الثابتة</td><td>${formatCurrency(f.fixed_expenses, currency)}</td></tr>
      <tr><td>المصروفات المتغيرة</td><td>${formatCurrency(f.variable_expenses, currency)}</td></tr>
      <tr><td>الأصول</td><td>${formatCurrency(f.assets, currency)}</td></tr>
      <tr><td>الخصوم</td><td>${formatCurrency(f.liabilities, currency)}</td></tr>
      <tr><td>التدفق النقدي الداخل</td><td>${formatCurrency(f.cash_inflow, currency)}</td></tr>
      <tr><td>التدفق النقدي الخارج</td><td>${formatCurrency(f.cash_outflow, currency)}</td></tr>
    </table>
  </div>

  <div class="section">
    <h2>السيناريوهات</h2>
    <table class="scenario-table">
      <tr><th>السيناريو</th><th>الإيرادات</th><th>المصروفات</th><th>الربح</th><th>التدفق النقدي</th><th>فترة الاسترداد</th></tr>
      ${scenarios.map((s) => `<tr style="background: ${s.color}11;">
        <td><strong style="color: ${s.color}">${s.label}</strong></td>
        <td>${formatCurrency(s.revenue, currency)}</td>
        <td>${formatCurrency(s.expenses, currency)}</td>
        <td>${formatCurrency(s.profit, currency)}</td>
        <td>${formatCurrency(s.cashFlow, currency)}</td>
        <td>${s.paybackPeriod > 0 ? formatNumber(s.paybackPeriod) + ' سنة' : '—'}</td>
      </tr>`).join('')}
    </table>
  </div>

  <div class="section">
    <h2>الخلاصة</h2>
    <p style="font-size: 13px; line-height: 1.8;">
      ${r.netProfit > 0
        ? `الوضع المالي إيجابي مع ربح صافي وهامش ربح ${formatPercent(r.profitMargin)}.`
        : `الوضع المالي يحتاج تحسينات، حيث توجد ${r.netProfit < 0 ? 'خسارة' : 'هامش ربح ضئيل'}.`
      }
      ${r.debtToAssets > 50 ? 'مستوى المديونية مرتفع ويستدعي الانتباه.' : 'مستوى المديونية ضمن حدود مقبولة.'}
      ${r.netCashFlow < 0 ? 'التدفق النقدي سالب ويحتاج إلى مراجعة.' : 'التدفق النقدي موجب وهو مؤشر جيد.'}
    </p>
  </div>
  `;
}
