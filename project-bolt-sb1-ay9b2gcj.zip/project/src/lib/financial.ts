import type { FeasibilityInput, FeasibilityResults, FinancialInput, FinancialResults, ScenarioData } from './types';

export function formatCurrency(value: number, currency = 'ريال'): string {
  const formatted = new Intl.NumberFormat('ar-EG', {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  }).format(Math.round(value * 100) / 100);
  return `${formatted} ${currency}`;
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('ar-EG', { maximumFractionDigits: 2 }).format(value);
}

export function formatPercent(value: number): string {
  return `${formatNumber(value)}٪`;
}

export function calculateFeasibility(input: FeasibilityInput): FeasibilityResults {
  const totalMonthlyCosts =
    (input.setup_costs / 12) +
    input.monthly_expenses +
    input.salaries +
    input.rent +
    input.marketing +
    input.product_cost;

  const monthlyRevenue = input.expected_monthly_revenue > 0
    ? input.expected_monthly_revenue
    : input.expected_customers * input.product_price;

  const netProfit = monthlyRevenue - totalMonthlyCosts;
  const profitMargin = monthlyRevenue > 0 ? (netProfit / monthlyRevenue) * 100 : 0;

  const totalInitialInvestment = input.capital + input.setup_costs;
  const breakEvenPoint = totalMonthlyCosts > 0 && input.product_price > 0
    ? totalMonthlyCosts / input.product_price
    : 0;

  const paybackPeriod = netProfit > 0 ? totalInitialInvestment / (netProfit * 12) : 0;

  // 12-month forecast with modest growth
  const growthRate = 0.03;
  const forecasts = Array.from({ length: 12 }, (_, i) => {
    const factor = Math.pow(1 + growthRate, i);
    const revenue = monthlyRevenue * factor;
    const expenses = totalMonthlyCosts * Math.pow(1 + 0.01, i);
    return { month: i + 1, revenue, expenses, profit: revenue - expenses };
  });

  const strengths: string[] = [];
  const weaknesses: string[] = [];
  const risks: string[] = [];
  const opportunities: string[] = [];
  const recommendations: string[] = [];

  if (profitMargin > 20) strengths.push('هامش ربح ممتاز يتجاوز 20٪، مما يدل على كفاءة عالية في التشغيل.');
  if (profitMargin > 0 && profitMargin <= 20) strengths.push('المشروع يحقق ربحاً موجباً مع هامش معقول.');
  if (paybackPeriod > 0 && paybackPeriod < 2) strengths.push('فترة استرداد رأس المال قصيرة (أقل من سنتين).');
  if (input.expected_customers > 100) strengths.push('قاعدة عملاء متوقعة كبيرة توفر استقراراً في الإيرادات.');
  if (input.capital > totalInitialInvestment * 0.5) strengths.push('رأس المال كافٍ لتغطية جزء كبير من الاستثمار الأولي.');
  if (input.marketing > 0) strengths.push('وجود ميزانية تسويقية تعزز فرص النمو.');

  if (profitMargin < 0) weaknesses.push('المشروع يعمل بخسارة على المدى القصير، مما يتطلب إعادة النظر في التكاليف أو الأسعار.');
  if (profitMargin >= 0 && profitMargin < 10) weaknesses.push('هامش الربح منخفض، مما يقلل من مرونة المشروع أمام التقلبات.');
  if (paybackPeriod > 3) weaknesses.push('فترة استرداد رأس المال طويلة (أكثر من 3 سنوات).');
  if (input.salaries > totalMonthlyCosts * 0.5) weaknesses.push('الرواتب تمثل عبئاً كبيراً على التكاليف التشغيلية.');
  if (input.rent > totalMonthlyCosts * 0.3) weaknesses.push('الإيجار مرتفع نسبياً مقارنة بإجمالي التكاليف.');
  if (input.capital < totalInitialInvestment * 0.3) weaknesses.push('رأس المال قد لا يكون كافياً لتغطية الاستثمار الأولي.');

  risks.push('تقلب الطلب في السوق قد يؤثر على الإيرادات المتوقعة.');
  if (input.expected_customers < 50) risks.push('قاعدة العملاء الصغيرة تزيد من مخاطر التذبذب.');
  risks.push('ارتفاع تكاليف المواد الخام أو الإيجار قد يقلل من هامش الربح.');
  if (paybackPeriod > 2) risks.push('فترة الاسترداد الطويلة تزيد من مخاطر عدم استرجاع رأس المال.');
  risks.push('المنافسة في السوق قد تؤدي إلى تخفيض الأسعار.');

  opportunities.push('إمكانية التوسع وزيادة حصة السوق عبر التسويق الرقمي.');
  opportunities.push('تنويع مصادر الإيرادات بمنتجات أو خدمات مكمّلة.');
  if (input.product_price > 0) opportunities.push('إمكانية رفع الأسعار تدريجياً مع بناء العلامة التجارية.');
  opportunities.push('شراكات استراتيجية مع موردين أو منصات توزيع.');
  opportunities.push('استغلال التكنولوجيا لأتمتة العمليات وتخفيض التكاليف.');

  if (profitMargin < 10) recommendations.push('العمل على زيادة هامش الربح إما برفع الأسعار أو تخفيض التكاليف المتغيرة.');
  recommendations.push('تخصيص ميزانية تسويقية فعّالة لجذب العملاء وزيادة المبيعات.');
  if (input.salaries > totalMonthlyCosts * 0.4) recommendations.push('مراجعة هيكل الرواتب وتقليل التكاليف عبر الأتمتة.');
  recommendations.push('بناء احتياطي نقدي يعادل 3-6 أشهر من التكاليف التشغيلية.');
  if (paybackPeriod > 2) recommendations.push('تسريع استرداد رأس المال عبر زيادة المبيعات أو تخفيض الاستثمار الأولي.');
  recommendations.push('إجراء دراسة سوق تفصيلية للتأكد من حجم الطلب الفعلي.');
  recommendations.push('متابعة المؤشرات المالية شهرياً وضبط الخطة حسب الأداء الفعلي.');

  const projectTypeLabel = input.project_type || 'المشروع';
  const summary = `مشروع "${input.project_name}" هو مشروع من نوع ${projectTypeLabel} في ${input.country || 'غير محدد'}${input.city ? ' - ' + input.city : ''}. ` +
    `يستهدف ${input.expected_customers} عميل شهرياً بسعر ${formatCurrency(input.product_price, input.currency)} للوحدة. ` +
    `إجمالي التكاليف الشهرية تبلغ ${formatCurrency(totalMonthlyCosts, input.currency)}، والإيرادات المتوقعة ${formatCurrency(monthlyRevenue, input.currency)}. ` +
    `${netProfit > 0 ? `يحقق المشروع صافي ربح شهري قدره ${formatCurrency(netProfit, input.currency)} بهامش ربح ${formatPercent(profitMargin)}.` : `المشروع يعاني من خسارة شهرية قدرها ${formatCurrency(Math.abs(netProfit), input.currency)}.`} ` +
    `${paybackPeriod > 0 ? `فترة استرداد رأس المال تقدر بـ ${formatNumber(paybackPeriod)} سنة.` : 'لا يمكن تحديد فترة استرداد رأس المال في الوضع الحالي.'}`;

  const marketAnalysis = `بناءً على المعطيات، يشير حجم العملاء المتوقع (${input.expected_customers} عميل/شهر) إلى ${input.expected_customers > 100 ? 'طلب جيد' : 'طلب محدود'}. ` +
    `سعر المنتج/الخدمة (${formatCurrency(input.product_price, input.currency)}) ${input.product_price > 0 ? 'يبدو تنافسياً' : 'لم يتم تحديده'}. ` +
    `وجود ميزانية تسويقية (${formatCurrency(input.marketing, input.currency)}) ${input.marketing > 0 ? 'يدعم فرص النمو والتوسع' : 'غير متوفرة، مما قد يحد من الوصول للعملاء'}. ` +
    `السوق المستهدف ${input.expected_customers > 200 ? 'واسع ويوفر فرصاً للتوسع المستقبلي' : 'متوسط ويتطلب استراتيجية تركيز على جودة الخدمة'}.`;

  return {
    summary,
    marketAnalysis,
    totalMonthlyCosts,
    monthlyRevenue,
    netProfit,
    profitMargin,
    breakEvenPoint,
    paybackPeriod,
    forecasts,
    strengths: strengths.length > 0 ? strengths : ['المشروع لديه إمكانيات للنمو مع التحسين المستمر.'],
    weaknesses: weaknesses.length > 0 ? weaknesses : ['لم يتم تحديد نقاط ضعف واضحة.'],
    risks,
    opportunities,
    recommendations: recommendations.length > 0 ? recommendations : ['المتابعة الدورية للأداء وضبط الخطة حسب الحاجة.'],
  };
}

export function calculateFinancial(input: FinancialInput): FinancialResults {
  const netProfit = input.revenue - input.expenses;
  const profitMargin = input.revenue > 0 ? (netProfit / input.revenue) * 100 : 0;
  const contributionMargin = input.revenue - input.variable_expenses;
  const contributionMarginRatio = input.revenue > 0 ? (contributionMargin / input.revenue) * 100 : 0;
  const breakEvenRevenue = contributionMarginRatio > 0 ? (input.fixed_expenses / contributionMarginRatio) * 100 : 0;
  const breakEvenUnits = contributionMargin > 0 ? input.fixed_expenses / contributionMargin : 0;
  const netCashFlow = input.cash_inflow - input.cash_outflow;
  const currentRatio = input.liabilities > 0 ? input.assets / input.liabilities : 0;
  const debtToAssets = input.assets > 0 ? (input.liabilities / input.assets) * 100 : 0;
  const roa = input.assets > 0 ? (netProfit / input.assets) * 100 : 0;
  const fixedCostRatio = input.expenses > 0 ? (input.fixed_expenses / input.expenses) * 100 : 0;
  const variableCostRatio = input.expenses > 0 ? (input.variable_expenses / input.expenses) * 100 : 0;
  const monthlyBurnRate = input.expenses - input.revenue > 0 ? input.expenses - input.revenue : 0;
  const runway = monthlyBurnRate > 0 && input.assets > 0 ? input.assets / monthlyBurnRate : 0;

  return {
    netProfit,
    profitMargin,
    breakEvenRevenue,
    breakEvenUnits,
    contributionMargin,
    contributionMarginRatio,
    netCashFlow,
    currentRatio,
    debtToAssets,
    roa,
    fixedCostRatio,
    variableCostRatio,
    monthlyBurnRate,
    runway,
    charts: {
      revenueVsExpenses: [
        { label: 'الإيرادات', value: input.revenue },
        { label: 'المصروفات', value: input.expenses },
        { label: 'صافي الربح', value: netProfit },
      ],
      costBreakdown: [
        { label: 'مصروفات ثابتة', value: input.fixed_expenses },
        { label: 'مصروفات متغيرة', value: input.variable_expenses },
      ],
      cashFlow: [
        { label: 'تدفق نقدي داخل', value: input.cash_inflow },
        { label: 'تدفق نقدي خارج', value: input.cash_outflow },
        { label: 'صافي التدفق', value: netCashFlow },
      ],
      assetsLiabilities: [
        { label: 'الأصول', value: input.assets },
        { label: 'الخصوم', value: input.liabilities },
        { label: 'صافي الملكية', value: input.assets - input.liabilities },
      ],
    },
  };
}

export function calculateScenarios(
  baseRevenue: number,
  baseExpenses: number,
  initialInvestment: number,
  currency: string
): ScenarioData[] {
  const scenarios: { name: string; label: string; revAdj: number; expAdj: number; color: string }[] = [
    { name: 'optimistic', label: 'متفائل', revAdj: 1.2, expAdj: 0.95, color: '#00e676' },
    { name: 'realistic', label: 'واقعي', revAdj: 1.0, expAdj: 1.0, color: '#00b0ff' },
    { name: 'pessimistic', label: 'متشائم', revAdj: 0.7, expAdj: 1.1, color: '#ff5252' },
  ];

  return scenarios.map((s) => {
    const revenue = baseRevenue * s.revAdj;
    const expenses = baseExpenses * s.expAdj;
    const profit = revenue - expenses;
    const cashFlow = profit;
    const paybackPeriod = profit > 0 ? initialInvestment / (profit * 12) : 0;
    return {
      name: s.name,
      label: s.label,
      revenueAdjustment: s.revAdj,
      expenseAdjustment: s.expAdj,
      revenue,
      expenses,
      profit,
      cashFlow,
      paybackPeriod,
      color: s.color,
    };
  });
}

export function calculateProfitCalculator(
  revenue: number,
  fixedCosts: number,
  variableCosts: number,
  productPrice: number
): {
  totalCosts: number;
  netProfit: number;
  profitMargin: number;
  breakEvenUnits: number;
  breakEvenRevenue: number;
  contributionMargin: number;
} {
  const totalCosts = fixedCosts + variableCosts;
  const netProfit = revenue - totalCosts;
  const profitMargin = revenue > 0 ? (netProfit / revenue) * 100 : 0;
  const contributionMargin = productPrice > 0 ? productPrice - (variableCosts / Math.max(revenue / productPrice, 1)) : 0;
  const breakEvenUnits = contributionMargin > 0 ? fixedCosts / contributionMargin : 0;
  const breakEvenRevenue = breakEvenUnits * productPrice;

  return {
    totalCosts,
    netProfit,
    profitMargin,
    breakEvenUnits,
    breakEvenRevenue,
    contributionMargin,
  };
}
