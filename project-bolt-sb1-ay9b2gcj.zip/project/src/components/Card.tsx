import type { ReactNode } from 'react';

interface CardProps {
  children: ReactNode;
  className?: string;
  hover?: boolean;
  glow?: 'green' | 'blue' | 'none';
  onClick?: () => void;
}

export function Card({ children, className = '', hover = false, glow = 'none', onClick }: CardProps) {
  const glowClass = glow === 'green' ? 'glow-green' : glow === 'blue' ? 'glow-blue' : '';
  return (
    <div
      onClick={onClick}
      className={`glass-card ${hover ? 'glass-card-hover cursor-pointer' : ''} ${glowClass} ${className}`}
    >
      {children}
    </div>
  );
}

interface StatCardProps {
  label: string;
  value: string;
  icon?: ReactNode;
  trend?: 'up' | 'down' | 'neutral';
  trendValue?: string;
  color?: 'green' | 'blue' | 'red' | 'amber' | 'default';
}

const colorClasses = {
  green: 'text-neon-green',
  blue: 'text-neon-blue',
  red: 'text-red-400',
  amber: 'text-amber-400',
  default: 'text-gray-200',
};

export function StatCard({ label, value, icon, trend, trendValue, color = 'default' }: StatCardProps) {
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm text-gray-400 mb-1">{label}</p>
          <p className={`text-2xl font-bold ${colorClasses[color]}`}>{value}</p>
          {trend && trendValue && (
            <p className={`text-xs mt-2 ${trend === 'up' ? 'text-neon-green' : trend === 'down' ? 'text-red-400' : 'text-gray-400'}`}>
              {trend === 'up' ? '▲' : trend === 'down' ? '▼' : '—'} {trendValue}
            </p>
          )}
        </div>
        {icon && <div className={`text-2xl ${colorClasses[color]}`}>{icon}</div>}
      </div>
    </Card>
  );
}
