interface BadgeProps {
  children: React.ReactNode;
  variant?: 'free' | 'premium' | 'admin' | 'default' | 'success' | 'warning' | 'error';
  size?: 'sm' | 'md';
}

const variantClasses = {
  free: 'bg-gray-700/50 text-gray-300 border border-gray-600/50',
  premium: 'gradient-blue text-white border border-neon-blue/30',
  admin: 'bg-amber-500/20 text-amber-300 border border-amber-500/30',
  default: 'bg-navy-700/50 text-gray-300 border border-navy-600/50',
  success: 'bg-neon-green/15 text-neon-green border border-neon-green/30',
  warning: 'bg-amber-500/15 text-amber-400 border border-amber-500/30',
  error: 'bg-red-500/15 text-red-400 border border-red-500/30',
};

const sizeClasses = {
  sm: 'text-xs px-2 py-0.5',
  md: 'text-sm px-3 py-1',
};

export function Badge({ children, variant = 'default', size = 'md' }: BadgeProps) {
  return (
    <span className={`inline-flex items-center gap-1 rounded-full font-medium ${variantClasses[variant]} ${sizeClasses[size]}`}>
      {children}
    </span>
  );
}
