interface ChartDataPoint {
  label: string;
  value: number;
  color?: string;
}

interface BarChartProps {
  data: ChartDataPoint[];
  height?: number;
  currency?: string;
  formatValue?: (v: number) => string;
}

const defaultColors = ['#00e676', '#00b0ff', '#ff5252', '#ffc107', '#7c4dff', '#18ffff'];

export function BarChart({ data, height = 200, currency = '', formatValue }: BarChartProps) {
  const maxVal = Math.max(...data.map((d) => Math.abs(d.value)), 1);
  const hasNegative = data.some((d) => d.value < 0);

  return (
    <div className="w-full" style={{ height: height + 40 }}>
      <div className="flex items-end justify-around gap-3 h-full pb-8 px-2 relative">
        {/* Zero line if negative values */}
        {hasNegative && (
          <div className="absolute left-0 right-0 border-t border-gray-600/30" style={{ top: '50%' }} />
        )}
        {data.map((d, i) => {
          const color = d.color || defaultColors[i % defaultColors.length];
          const barHeight = (Math.abs(d.value) / maxVal) * 100;
          const isNegative = d.value < 0;
          return (
            <div key={i} className="flex-1 flex flex-col items-center justify-end h-full relative group">
              <div className="absolute -top-6 opacity-0 group-hover:opacity-100 transition-opacity bg-navy-900 text-xs text-gray-200 px-2 py-1 rounded-md whitespace-nowrap z-10 border border-navy-700">
                {formatValue ? formatValue(d.value) : `${d.value.toLocaleString()} ${currency}`}
              </div>
              <div
                className="w-full max-w-[60px] rounded-t-lg transition-all duration-300 hover:opacity-80"
                style={{
                  height: `${barHeight}%`,
                  background: `linear-gradient(180deg, ${color} 0%, ${color}88 100%)`,
                  boxShadow: `0 0 15px ${color}30`,
                  marginBottom: isNegative ? 'auto' : '0',
                  marginTop: isNegative ? '0' : 'auto',
                  borderRadius: isNegative ? '0 0 8px 8px' : '8px 8px 0 0',
                }}
              />
              <span className="text-xs text-gray-400 mt-2 text-center truncate w-full">{d.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
}

interface LineChartProps {
  data: { label: string; value: number; value2?: number }[];
  height?: number;
  color?: string;
  color2?: string;
  showSecond?: boolean;
}

export function LineChart({ data, height = 200, color = '#00e676', color2 = '#00b0ff', showSecond = false }: LineChartProps) {
  const maxVal = Math.max(...data.flatMap((d) => [d.value, d.value2 || 0]), 1);
  const minVal = Math.min(...data.flatMap((d) => [d.value, d.value2 || 0]), 0);
  const range = maxVal - minVal || 1;
  const width = 100;
  const stepX = width / Math.max(data.length - 1, 1);

  const points = data.map((d, i) => {
    const x = i * stepX;
    const y = height - ((d.value - minVal) / range) * height;
    return { x, y };
  });

  const points2 = data.map((d, i) => {
    const x = i * stepX;
    const y = height - ((d.value2! - minVal) / range) * height;
    return { x, y };
  });

  const pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');
  const areaD = `${pathD} L ${width} ${height} L 0 ${height} Z`;
  const pathD2 = points2.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

  return (
    <div className="w-full">
      <svg viewBox={`0 0 ${width} ${height}`} className="w-full" style={{ height }} preserveAspectRatio="none">
        <defs>
          <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor={color} stopOpacity="0.3" />
            <stop offset="100%" stopColor={color} stopOpacity="0" />
          </linearGradient>
        </defs>
        {/* Grid lines */}
        {[0.25, 0.5, 0.75].map((p) => (
          <line key={p} x1="0" y1={height * p} x2={width} y2={height * p} stroke="#244070" strokeWidth="0.2" />
        ))}
        <path d={areaD} fill="url(#areaGrad)" />
        <path d={pathD} fill="none" stroke={color} strokeWidth="0.5" strokeLinejoin="round" />
        {points.map((p, i) => (
          <circle key={i} cx={p.x} cy={p.y} r="0.8" fill={color} />
        ))}
        {showSecond && (
          <>
            <path d={pathD2} fill="none" stroke={color2} strokeWidth="0.5" strokeDasharray="2 1" strokeLinejoin="round" />
            {points2.map((p, i) => (
              <circle key={`p2-${i}`} cx={p.x} cy={p.y} r="0.6" fill={color2} />
            ))}
          </>
        )}
      </svg>
      <div className="flex justify-between mt-1 px-1">
        {data.map((d, i) => (
          <span key={i} className="text-[10px] text-gray-500">{d.label}</span>
        ))}
      </div>
    </div>
  );
}

interface DonutChartProps {
  data: ChartDataPoint[];
  size?: number;
  centerLabel?: string;
  centerValue?: string;
}

export function DonutChart({ data, size = 160, centerLabel, centerValue }: DonutChartProps) {
  const total = data.reduce((sum, d) => sum + Math.abs(d.value), 0) || 1;
  const radius = size / 2 - 10;
  const innerRadius = radius * 0.6;
  const center = size / 2;

  let cumulativeAngle = -Math.PI / 2;

  const segments = data.map((d, i) => {
    const angle = (Math.abs(d.value) / total) * Math.PI * 2;
    const startAngle = cumulativeAngle;
    const endAngle = cumulativeAngle + angle;
    cumulativeAngle = endAngle;

    const x1 = center + radius * Math.cos(startAngle);
    const y1 = center + radius * Math.sin(startAngle);
    const x2 = center + radius * Math.cos(endAngle);
    const y2 = center + radius * Math.sin(endAngle);
    const x3 = center + innerRadius * Math.cos(endAngle);
    const y3 = center + innerRadius * Math.sin(endAngle);
    const x4 = center + innerRadius * Math.cos(startAngle);
    const y4 = center + innerRadius * Math.sin(startAngle);

    const largeArc = angle > Math.PI ? 1 : 0;
    const color = d.color || defaultColors[i % defaultColors.length];

    const path = `M ${x1} ${y1} A ${radius} ${radius} 0 ${largeArc} 1 ${x2} ${y2} L ${x3} ${y3} A ${innerRadius} ${innerRadius} 0 ${largeArc} 0 ${x4} ${y4} Z`;

    return { path, color, label: d.label, value: d.value, percent: (Math.abs(d.value) / total) * 100 };
  });

  return (
    <div className="flex flex-col items-center gap-4">
      <svg width={size} height={size} viewBox={`0 0 ${size} ${size}`}>
        {segments.map((seg, i) => (
          <path key={i} d={seg.path} fill={seg.color} opacity="0.85" className="hover:opacity-100 transition-opacity" />
        ))}
        {centerValue && (
          <text x={center} y={center - 2} textAnchor="middle" className="fill-white text-base font-bold" style={{ fontSize: size * 0.12 }}>
            {centerValue}
          </text>
        )}
        {centerLabel && (
          <text x={center} y={center + size * 0.1} textAnchor="middle" className="fill-gray-400" style={{ fontSize: size * 0.07 }}>
            {centerLabel}
          </text>
        )}
      </svg>
      <div className="space-y-1.5">
        {segments.map((seg, i) => (
          <div key={i} className="flex items-center gap-2 text-sm">
            <span className="w-3 h-3 rounded-sm" style={{ backgroundColor: seg.color }} />
            <span className="text-gray-300">{seg.label}</span>
            <span className="text-gray-500 text-xs">({seg.percent.toFixed(1)}٪)</span>
          </div>
        ))}
      </div>
    </div>
  );
}

interface ComparisonBarProps {
  label: string;
  values: { label: string; value: number; color: string }[];
  max: number;
  formatValue?: (v: number) => string;
}

export function ComparisonBar({ label, values, max, formatValue }: ComparisonBarProps) {
  return (
    <div className="mb-4">
      <p className="text-sm text-gray-400 mb-2">{label}</p>
      <div className="space-y-2">
        {values.map((v, i) => (
          <div key={i} className="flex items-center gap-3">
            <span className="text-xs text-gray-400 w-16 shrink-0">{v.label}</span>
            <div className="flex-1 h-6 bg-navy-950/60 rounded-lg overflow-hidden relative">
              <div
                className="h-full rounded-lg transition-all duration-500 flex items-center justify-end pr-2"
                style={{
                  width: `${(Math.abs(v.value) / max) * 100}%`,
                  background: `linear-gradient(90deg, ${v.color}88 0%, ${v.color} 100%)`,
                  minWidth: '30px',
                }}
              >
                <span className="text-xs text-white font-medium whitespace-nowrap">
                  {formatValue ? formatValue(v.value) : v.value.toLocaleString()}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
