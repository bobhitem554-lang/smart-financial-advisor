interface RobotMascotProps {
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
  animated?: boolean;
}

const sizeMap = {
  sm: { box: 'w-10 h-10', eye: 'w-2 h-2', antenna: 'w-0.5 h-3', gap: 'gap-1.5' },
  md: { box: 'w-16 h-16', eye: 'w-3 h-3', antenna: 'w-1 h-4', gap: 'gap-2' },
  lg: { box: 'w-24 h-24', eye: 'w-4 h-4', antenna: 'w-1 h-5', gap: 'gap-3' },
  xl: { box: 'w-32 h-32', eye: 'w-5 h-5', antenna: 'w-1.5 h-6', gap: 'gap-4' },
};

export function RobotMascot({ size = 'md', className = '', animated = true }: RobotMascotProps) {
  const s = sizeMap[size];
  return (
    <div className={`inline-flex flex-col items-center ${animated ? 'animate-float' : ''} ${className}`}>
      {/* Antenna */}
      <div className="flex flex-col items-center">
        <div className={`${s.antenna} bg-gradient-to-t from-neon-green to-neon-cyan rounded-full`} />
        <div className={`w-1.5 h-1.5 rounded-full bg-neon-green shadow-lg shadow-neon-green/50 -mt-0.5`} />
      </div>
      {/* Head */}
      <div className={`${s.box} relative rounded-2xl bg-gradient-to-br from-navy-700 to-navy-800 border border-neon-green/20 ${animated ? 'animate-pulse-glow' : ''}`}>
        {/* Eyes */}
        <div className={`absolute inset-0 flex items-center justify-center ${s.gap}`}>
          <div className={`${s.eye} rounded-full bg-neon-green shadow-lg shadow-neon-green/50 ${animated ? 'animate-bounce-slow' : ''}`} />
          <div className={`${s.eye} rounded-full bg-neon-blue shadow-lg shadow-neon-blue/50 ${animated ? 'animate-bounce-slow' : ''}`} style={{ animationDelay: '0.3s' }} />
        </div>
        {/* Mouth */}
        <div className="absolute bottom-2 left-1/2 -translate-x-1/2 w-1/3 h-0.5 rounded-full bg-neon-green/40" />
        {/* Side details */}
        <div className="absolute top-1/2 -translate-y-1/2 right-0 w-1 h-1/3 rounded-l bg-neon-green/20" />
        <div className="absolute top-1/2 -translate-y-1/2 left-0 w-1 h-1/3 rounded-r bg-neon-blue/20" />
      </div>
    </div>
  );
}
