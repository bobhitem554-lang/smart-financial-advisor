import type { InputHTMLAttributes, SelectHTMLAttributes, TextareaHTMLAttributes, ReactNode } from 'react';

interface FieldProps {
  label: string;
  error?: string;
  hint?: string;
  required?: boolean;
  children: ReactNode;
}

export function Field({ label, error, hint, required, children }: FieldProps) {
  return (
    <div className="mb-4">
      <label className="block text-sm text-gray-300 mb-1.5 font-medium">
        {label}
        {required && <span className="text-neon-green mr-1">*</span>}
      </label>
      {children}
      {hint && !error && <p className="text-xs text-gray-500 mt-1">{hint}</p>}
      {error && <p className="text-xs text-red-400 mt-1">{error}</p>}
    </div>
  );
}

const baseInputClass =
  'w-full bg-navy-950/50 border border-navy-700/60 rounded-xl px-4 py-3 text-gray-100 placeholder-gray-500 ' +
  'focus:outline-none focus:border-neon-green/40 focus:ring-1 focus:ring-neon-green/20 transition-all duration-200';

interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  suffix?: string;
}

export function Input({ suffix, className = '', ...rest }: InputProps) {
  if (suffix) {
    return (
      <div className="relative">
        <input className={`${baseInputClass} pl-16 ${className}`} {...rest} />
        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm text-gray-500 pointer-events-none">
          {suffix}
        </span>
      </div>
    );
  }
  return <input className={`${baseInputClass} ${className}`} {...rest} />;
}

export function Select({ className = '', children, ...rest }: SelectHTMLAttributes<HTMLSelectElement> & { children: ReactNode }) {
  return (
    <select className={`${baseInputClass} cursor-pointer ${className}`} {...rest}>
      {children}
    </select>
  );
}

export function Textarea({ className = '', ...rest }: TextareaHTMLAttributes<HTMLTextAreaElement>) {
  return <textarea className={`${baseInputClass} resize-none ${className}`} {...rest} />;
}
