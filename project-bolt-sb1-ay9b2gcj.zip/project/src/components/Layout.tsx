import { useState, type ReactNode } from 'react';
import {
  Home, FileSearch, BarChart3, Upload, MessageCircle, Calculator,
  TrendingUp, LogOut, User, Shield, Menu, X, Bot, Sparkles, Crown,
} from 'lucide-react';
import { useAuth } from '@/lib/auth';
import { useRouter, type Route } from '@/lib/router';
import { Badge } from './Badge';
import { RobotMascot } from './RobotMascot';

interface NavItem {
  route: Route;
  label: string;
  icon: ReactNode;
}

const navItems: NavItem[] = [
  { route: 'home', label: 'الرئيسية', icon: <Home size={20} /> },
  { route: 'feasibility', label: 'دراسة جدوى جديدة', icon: <FileSearch size={20} /> },
  { route: 'financial', label: 'تحليل مالي', icon: <BarChart3 size={20} /> },
  { route: 'files', label: 'رفع ملف', icon: <Upload size={20} /> },
  { route: 'calculator', label: 'حاسبة الأرباح', icon: <Calculator size={20} /> },
  { route: 'scenarios', label: 'السيناريوهات', icon: <TrendingUp size={20} /> },
  { route: 'advisor', label: 'اسأل المستشار الذكي', icon: <MessageCircle size={20} /> },
  { route: 'plans', label: 'خطط الاشتراك', icon: <Crown size={20} /> },
];

export function Layout({ children }: { children: ReactNode }) {
  const { profile, signOut } = useAuth();
  const { route, navigate } = useRouter();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const handleNavigate = (r: Route) => {
    navigate(r);
    setSidebarOpen(false);
  };

  const handleSignOut = async () => {
    await signOut();
    navigate('home');
    setSidebarOpen(false);
  };

  const SidebarContent = (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-navy-700/40">
        <RobotMascot size="sm" animated={false} />
        <div>
          <h1 className="text-sm font-bold text-white leading-tight">مستشارك المالي الذكي</h1>
          <p className="text-[10px] text-gray-500">حلّل، افهم، قرر</p>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto py-4 px-3 space-y-1">
        {navItems.map((item) => (
          <button
            key={item.route}
            onClick={() => handleNavigate(item.route)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all duration-200 ${
              route === item.route
                ? 'bg-neon-green/10 text-neon-green border border-neon-green/20'
                : 'text-gray-400 hover:bg-navy-800/40 hover:text-gray-200'
            }`}
          >
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}

        {profile && (
          <>
            <div className="pt-3 mt-3 border-t border-navy-700/40 space-y-1">
              <button
                onClick={() => handleNavigate('profile')}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${
                  route === 'profile' ? 'bg-neon-blue/10 text-neon-blue' : 'text-gray-400 hover:bg-navy-800/40 hover:text-gray-200'
                }`}
              >
                <User size={20} />
                <span>الملف الشخصي</span>
              </button>
              {profile.role === 'admin' && (
                <button
                  onClick={() => handleNavigate('admin')}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl text-sm transition-all ${
                    route === 'admin' ? 'bg-amber-500/10 text-amber-400' : 'text-gray-400 hover:bg-navy-800/40 hover:text-gray-200'
                  }`}
                >
                  <Shield size={20} />
                  <span>لوحة الإدارة</span>
                </button>
              )}
            </div>
          </>
        )}
      </nav>

      {/* Footer */}
      <div className="border-t border-navy-700/40 p-3 space-y-2">
        {profile ? (
          <>
            <div className="flex items-center justify-between px-3 py-2 rounded-xl bg-navy-800/40">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-full gradient-green flex items-center justify-center text-navy-950 text-xs font-bold">
                  {profile.full_name?.[0] || profile.email[0].toUpperCase()}
                </div>
                <div className="text-xs">
                  <p className="text-gray-200 truncate max-w-[100px]">{profile.full_name || 'مستخدم'}</p>
                  <p className="text-gray-500 truncate max-w-[100px]">{profile.email}</p>
                </div>
              </div>
              <Badge variant={profile.plan} size="sm">
                {profile.plan === 'premium' ? <><Crown size={10} /> Premium</> : 'مجاني'}
              </Badge>
            </div>
            <button
              onClick={handleSignOut}
              className="w-full flex items-center gap-2 px-3 py-2 rounded-xl text-sm text-red-400/80 hover:bg-red-500/10 transition-all"
            >
              <LogOut size={18} />
              <span>تسجيل الخروج</span>
            </button>
          </>
        ) : (
          <div className="flex gap-2">
            <button
              onClick={() => handleNavigate('login')}
              className="flex-1 px-3 py-2 rounded-xl text-sm text-gray-300 bg-navy-800/40 hover:bg-navy-800/60 transition-all"
            >
              تسجيل الدخول
            </button>
            <button
              onClick={() => handleNavigate('signup')}
              className="flex-1 px-3 py-2 rounded-xl text-sm text-navy-950 gradient-green font-medium hover:opacity-90 transition-all"
            >
              إنشاء حساب
            </button>
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen gradient-hero grid-pattern">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex fixed top-0 right-0 h-screen w-72 glass-card rounded-none border-l border-navy-700/40 z-40">
        {SidebarContent}
      </aside>

      {/* Mobile sidebar */}
      {sidebarOpen && (
        <div className="lg:hidden fixed inset-0 z-50 animate-fade-in">
          <div className="absolute inset-0 bg-navy-950/80 backdrop-blur-sm" onClick={() => setSidebarOpen(false)} />
          <aside className="absolute top-0 right-0 h-screen w-72 glass-card rounded-none border-l border-navy-700/40 animate-slide-in">
            <button
              onClick={() => setSidebarOpen(false)}
              className="absolute top-4 left-4 text-gray-400 hover:text-white p-1"
            >
              <X size={24} />
            </button>
            {SidebarContent}
          </aside>
        </div>
      )}

      {/* Main content */}
      <div className="lg:pr-72">
        {/* Mobile header */}
        <header className="lg:hidden sticky top-0 z-30 glass-card rounded-none border-b border-navy-700/40 px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <RobotMascot size="sm" animated={false} />
            <span className="text-sm font-bold text-white">مستشارك المالي الذكي</span>
          </div>
          <button
            onClick={() => setSidebarOpen(true)}
            className="text-gray-400 hover:text-white p-2 rounded-lg hover:bg-navy-800/50"
          >
            <Menu size={22} />
          </button>
        </header>

        <main className="min-h-screen p-4 sm:p-6 lg:p-8 max-w-6xl mx-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

export function PageHeader({ title, subtitle, icon }: { title: string; subtitle?: string; icon?: ReactNode }) {
  return (
    <div className="flex items-center gap-3 mb-6 animate-slide-up">
      {icon && (
        <div className="w-12 h-12 rounded-2xl bg-navy-800/60 border border-neon-green/20 flex items-center justify-center text-neon-green">
          {icon}
        </div>
      )}
      <div>
        <h1 className="text-2xl font-bold text-white">{title}</h1>
        {subtitle && <p className="text-sm text-gray-400 mt-1">{subtitle}</p>}
      </div>
    </div>
  );
}

export function UpgradePrompt({ message, onUpgrade }: { message: string; onUpgrade?: () => void }) {
  return (
    <div className="glass-card p-6 text-center border-amber-500/20">
      <div className="inline-flex w-14 h-14 rounded-2xl bg-amber-500/10 items-center justify-center mb-3">
        <Sparkles size={24} className="text-amber-400" />
      </div>
      <p className="text-gray-300 mb-4">{message}</p>
      <button
        onClick={onUpgrade}
        className="inline-flex items-center gap-2 px-5 py-2.5 rounded-xl gradient-blue text-white font-medium text-sm hover:opacity-90 transition-all"
      >
        <Crown size={16} />
        الترقية إلى Premium
      </button>
    </div>
  );
}

export function BotIcon() {
  return <Bot size={20} />;
}
