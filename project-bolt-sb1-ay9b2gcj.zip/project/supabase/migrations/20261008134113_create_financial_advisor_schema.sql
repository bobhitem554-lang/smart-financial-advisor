/*
# Create schema for "مستشارك المالي الذكي" (Smart Financial Advisor)

## Overview
This migration creates the complete database schema for an Arabic financial advisor web app.
It includes user profiles, feasibility studies, financial analyses, file uploads, advisor chat sessions,
plan limits, usage tracking, and app settings.

## Privacy & 24-hour auto-expiry
All user-data tables (feasibility_studies, financial_analyses, file_uploads, advisor_sessions)
include an `expires_at` timestamptz column defaulting to now() + interval '24 hours'.
The app filters out expired rows. A cron-based cleanup can be added later.

## Tables created
1. **profiles** — extends auth.users with plan info (free/premium) and role (user/admin)
2. **plan_limits** — configurable usage limits per plan (admin-editable)
3. **feasibility_studies** — feasibility study inputs and results
4. **financial_analyses** — financial analysis inputs and results
5. **file_uploads** — metadata for uploaded files (no file content stored in DB)
6. **advisor_sessions** — chat sessions with the AI advisor
7. **usage_tracking** — counts of analyses/studies/uploads per user per period
8. **app_settings** — global app configuration (admin-editable)

## Security
- RLS enabled on all tables.
- User-data tables: owner-scoped (auth.uid() = user_id) for authenticated users.
- plan_limits / app_settings: readable by authenticated, writable by admin only.
- profiles: user can read/update own profile; admin can read all profiles.
- usage_tracking: user can read own, insert own, admin can read all.
*/

-- ============================================================
-- 1. profiles
-- ============================================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text NOT NULL,
  full_name text DEFAULT '',
  plan text NOT NULL DEFAULT 'free' CHECK (plan IN ('free', 'premium')),
  role text NOT NULL DEFAULT 'user' CHECK (role IN ('user', 'admin')),
  avatar_url text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_own" ON profiles;
CREATE POLICY "profiles_select_own" ON profiles FOR SELECT
  TO authenticated USING (auth.uid() = id OR EXISTS (SELECT 1 FROM profiles p WHERE p.id = auth.uid() AND p.role = 'admin'));

DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ============================================================
-- 2. plan_limits
-- ============================================================
CREATE TABLE IF NOT EXISTS plan_limits (
  plan text PRIMARY KEY CHECK (plan IN ('free', 'premium')),
  max_feasibility_studies int NOT NULL DEFAULT 3,
  max_financial_analyses int NOT NULL DEFAULT 5,
  max_file_uploads int NOT NULL DEFAULT 3,
  max_advisor_messages int NOT NULL DEFAULT 10,
  advanced_analysis boolean NOT NULL DEFAULT false,
  advanced_pdf boolean NOT NULL DEFAULT false,
  scenarios_enabled boolean NOT NULL DEFAULT false,
  file_analysis_enabled boolean NOT NULL DEFAULT false,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE plan_limits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "plan_limits_select" ON plan_limits;
CREATE POLICY "plan_limits_select" ON plan_limits FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "plan_limits_update_admin" ON plan_limits;
CREATE POLICY "plan_limits_update_admin" ON plan_limits FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

-- Seed default limits
INSERT INTO plan_limits (plan, max_feasibility_studies, max_financial_analyses, max_file_uploads, max_advisor_messages, advanced_analysis, advanced_pdf, scenarios_enabled, file_analysis_enabled)
VALUES ('free', 3, 5, 3, 10, false, false, false, false)
ON CONFLICT (plan) DO NOTHING;

INSERT INTO plan_limits (plan, max_feasibility_studies, max_financial_analyses, max_file_uploads, max_advisor_messages, advanced_analysis, advanced_pdf, scenarios_enabled, file_analysis_enabled)
VALUES ('premium', 100, 200, 50, 500, true, true, true, true)
ON CONFLICT (plan) DO NOTHING;

-- ============================================================
-- 3. feasibility_studies
-- ============================================================
CREATE TABLE IF NOT EXISTS feasibility_studies (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  project_name text NOT NULL,
  project_type text DEFAULT '',
  country text DEFAULT '',
  city text DEFAULT '',
  currency text DEFAULT 'ريال',
  capital numeric DEFAULT 0,
  setup_costs numeric DEFAULT 0,
  monthly_expenses numeric DEFAULT 0,
  product_cost numeric DEFAULT 0,
  employee_count int DEFAULT 0,
  salaries numeric DEFAULT 0,
  rent numeric DEFAULT 0,
  marketing numeric DEFAULT 0,
  expected_monthly_revenue numeric DEFAULT 0,
  expected_customers int DEFAULT 0,
  product_price numeric DEFAULT 0,
  additional_info text DEFAULT '',
  results jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT now() + interval '24 hours'
);

ALTER TABLE feasibility_studies ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "fs_select_own" ON feasibility_studies;
CREATE POLICY "fs_select_own" ON feasibility_studies FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "fs_insert_own" ON feasibility_studies;
CREATE POLICY "fs_insert_own" ON feasibility_studies FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "fs_update_own" ON feasibility_studies;
CREATE POLICY "fs_update_own" ON feasibility_studies FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "fs_delete_own" ON feasibility_studies;
CREATE POLICY "fs_delete_own" ON feasibility_studies FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_fs_user_id ON feasibility_studies(user_id);
CREATE INDEX IF NOT EXISTS idx_fs_expires_at ON feasibility_studies(expires_at);

-- ============================================================
-- 4. financial_analyses
-- ============================================================
CREATE TABLE IF NOT EXISTS financial_analyses (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT 'تحليل مالي',
  revenue numeric DEFAULT 0,
  expenses numeric DEFAULT 0,
  fixed_expenses numeric DEFAULT 0,
  variable_expenses numeric DEFAULT 0,
  assets numeric DEFAULT 0,
  liabilities numeric DEFAULT 0,
  cash_inflow numeric DEFAULT 0,
  cash_outflow numeric DEFAULT 0,
  results jsonb DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT now() + interval '24 hours'
);

ALTER TABLE financial_analyses ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "fa_select_own" ON financial_analyses;
CREATE POLICY "fa_select_own" ON financial_analyses FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "fa_insert_own" ON financial_analyses;
CREATE POLICY "fa_insert_own" ON financial_analyses FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "fa_update_own" ON financial_analyses;
CREATE POLICY "fa_update_own" ON financial_analyses FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "fa_delete_own" ON financial_analyses;
CREATE POLICY "fa_delete_own" ON financial_analyses FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_fa_user_id ON financial_analyses(user_id);
CREATE INDEX IF NOT EXISTS idx_fa_expires_at ON financial_analyses(expires_at);

-- ============================================================
-- 5. file_uploads
-- ============================================================
CREATE TABLE IF NOT EXISTS file_uploads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  file_name text NOT NULL,
  file_type text NOT NULL,
  file_size bigint DEFAULT 0,
  extracted_data jsonb DEFAULT '{}',
  analysis_result jsonb DEFAULT '{}',
  status text DEFAULT 'pending' CHECK (status IN ('pending', 'processing', 'completed', 'failed')),
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT now() + interval '24 hours'
);

ALTER TABLE file_uploads ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "fu_select_own" ON file_uploads;
CREATE POLICY "fu_select_own" ON file_uploads FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "fu_insert_own" ON file_uploads;
CREATE POLICY "fu_insert_own" ON file_uploads FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "fu_update_own" ON file_uploads;
CREATE POLICY "fu_update_own" ON file_uploads FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "fu_delete_own" ON file_uploads;
CREATE POLICY "fu_delete_own" ON file_uploads FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_fu_user_id ON file_uploads(user_id);
CREATE INDEX IF NOT EXISTS idx_fu_expires_at ON file_uploads(expires_at);

-- ============================================================
-- 6. advisor_sessions
-- ============================================================
CREATE TABLE IF NOT EXISTS advisor_sessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  context_type text DEFAULT 'general' CHECK (context_type IN ('general', 'feasibility', 'financial', 'file')),
  context_id uuid,
  messages jsonb NOT NULL DEFAULT '[]'::jsonb,
  message_count int DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  expires_at timestamptz DEFAULT now() + interval '24 hours'
);

ALTER TABLE advisor_sessions ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "as_select_own" ON advisor_sessions;
CREATE POLICY "as_select_own" ON advisor_sessions FOR SELECT
  TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "as_insert_own" ON advisor_sessions;
CREATE POLICY "as_insert_own" ON advisor_sessions FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "as_update_own" ON advisor_sessions;
CREATE POLICY "as_update_own" ON advisor_sessions FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "as_delete_own" ON advisor_sessions;
CREATE POLICY "as_delete_own" ON advisor_sessions FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_as_user_id ON advisor_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_as_expires_at ON advisor_sessions(expires_at);

-- ============================================================
-- 7. usage_tracking
-- ============================================================
CREATE TABLE IF NOT EXISTS usage_tracking (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  action text NOT NULL CHECK (action IN ('feasibility_study', 'financial_analysis', 'file_upload', 'advisor_message', 'pdf_export')),
  period text NOT NULL DEFAULT to_char(now(), 'YYYY-MM'),
  created_at timestamptz DEFAULT now()
);

ALTER TABLE usage_tracking ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "ut_select_own" ON usage_tracking;
CREATE POLICY "ut_select_own" ON usage_tracking FOR SELECT
  TO authenticated USING (auth.uid() = user_id OR EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

DROP POLICY IF EXISTS "ut_insert_own" ON usage_tracking;
CREATE POLICY "ut_insert_own" ON usage_tracking FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "ut_delete_own" ON usage_tracking;
CREATE POLICY "ut_delete_own" ON usage_tracking FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS idx_ut_user_id ON usage_tracking(user_id);
CREATE INDEX IF NOT EXISTS idx_ut_action ON usage_tracking(action);
CREATE INDEX IF NOT EXISTS idx_ut_period ON usage_tracking(period);

-- ============================================================
-- 8. app_settings
-- ============================================================
CREATE TABLE IF NOT EXISTS app_settings (
  id int PRIMARY KEY DEFAULT 1,
  app_name text NOT NULL DEFAULT 'مستشارك المالي الذكي',
  app_tagline text NOT NULL DEFAULT 'حلّل مشروعك، افهم أرقامك، واتخذ قرارك بثقة.',
  contact_email text DEFAULT '',
  maintenance_mode boolean DEFAULT false,
  updated_at timestamptz DEFAULT now(),
  CONSTRAINT single_row CHECK (id = 1)
);

ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "app_settings_select" ON app_settings;
CREATE POLICY "app_settings_select" ON app_settings FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "app_settings_update_admin" ON app_settings;
CREATE POLICY "app_settings_update_admin" ON app_settings FOR UPDATE
  TO authenticated USING (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'))
  WITH CHECK (EXISTS (SELECT 1 FROM profiles WHERE id = auth.uid() AND role = 'admin'));

INSERT INTO app_settings (id) VALUES (1) ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- Trigger: auto-create profile on signup
-- ============================================================
CREATE OR REPLACE FUNCTION handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO profiles (id, email, full_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'full_name', ''))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION handle_new_user();

-- ============================================================
-- Updated_at triggers
-- ============================================================
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS trigger
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS profiles_updated_at ON profiles;
CREATE TRIGGER profiles_updated_at BEFORE UPDATE ON profiles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS plan_limits_updated_at ON plan_limits;
CREATE TRIGGER plan_limits_updated_at BEFORE UPDATE ON plan_limits
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

DROP TRIGGER IF EXISTS app_settings_updated_at ON app_settings;
CREATE TRIGGER app_settings_updated_at BEFORE UPDATE ON app_settings
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();